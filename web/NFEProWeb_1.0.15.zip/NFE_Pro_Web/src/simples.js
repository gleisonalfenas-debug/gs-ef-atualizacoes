// Simples Nacional: alíquota efetiva e partilha (LC 123, anexos na redação da LC 214/2025, anos 2027-2028;
// a parte do ICMS é igual à de 2026). Usado para calcular sozinho o crédito de ICMS e as alíquotas de IBS/CBS.
export const SN = {
  I: { f: [[180e3, 4, 0], [360e3, 7.3, 5940], [720e3, 9.5, 13860], [1.8e6, 10.7, 22500], [3.6e6, 14.3, 87300], [4.8e6, 18.9, 378000]],
    icms: [34, 34, 33.5, 33.5, 33.5, 0], cbs: [15.33, 15.33, 15.33, 15.33, 15.33, 34.02], ibs: [.17, .17, .17, .17, .17, 0] },
  II: { f: [[180e3, 4.5, 0], [360e3, 7.8, 5940], [720e3, 10, 13860], [1.8e6, 11.2, 22500], [3.6e6, 14.7, 85500], [4.8e6, 29.9, 720000]],
    icms: [32, 32, 32, 32, 32, 0], cbs: [13.85, 13.85, 13.85, 13.85, 13.85, 25.22], ibs: [.15, .15, .15, .15, .15, 0] },
};
const r4 = v => Math.round(v * 1e4) / 1e4;
export function calcSN(anexo, rbt) {
  const t = SN[anexo] || SN.I; rbt = +rbt || 0; if (rbt <= 0) return null;
  const k = t.f.findIndex(x => rbt <= x[0]); if (k < 0) return { erro: "RBT12 acima de R$ 4,8 milhões." };
  const [, nom, ded] = t.f[k], ef = k === 0 ? nom : (rbt * nom / 100 - ded) / rbt * 100;
  return { faixa: k + 1, ef: r4(ef), icms: r4(ef * t.icms[k] / 100), cbs: r4(ef * t.cbs[k] / 100), ibs: r4(ef * t.ibs[k] / 100) };
}
// Receita das notas: vendas somam (CFOP x101-x125 e x401-x405); devolução de venda (x202/x411 de entrada) subtrai; remessas não contam.
const VENDA = /^[567](1(0[1-9]|1\d|2[0-5])|40[1-5])$/, DEVOL = /^[12](20[12]|41[01])$/;
export function receitaDaNota(dados, total) {
  let d = {}; try { d = JSON.parse(dados || "{}"); } catch { /* sem dados */ }
  const it = d.itens || []; if (!it.length) return 0;
  const val = i => (+i.quantidade) * (+i.preco) - (+i.desconto || 0);
  let v = 0, devol = 0;
  for (const i of it) { const c = String(i.cfop || "").replace(/\D/g, ""); if (VENDA.test(c) || VENDA.test("5" + c.slice(1))) v += val(i); else if (DEVOL.test(c)) devol += val(i); }
  return Math.round((v - devol) * 100) / 100;
}
// RBT12 do mês "mes" (AAAA-MM) = receita dos 12 meses anteriores.
export function periodoRBT12(mes) {
  const [a, m] = mes.split("-").map(Number), ini = new Date(Date.UTC(a, m - 13, 1)).toISOString().slice(0, 7);
  return { ini, fim: mes };   // ini <= mês da nota < fim
}
