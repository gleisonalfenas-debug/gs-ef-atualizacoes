// NFE Pro Web — servidor (Cloudflare Worker). As telas ficam em public/ (Workers Static Assets);
// aqui ficam a API (/api/...), o DANFE (/danfe/<chave>) e o XML (/xml/<chave>).
import * as N from "./nfe.js";
import { danfeHTML } from "./danfe.js";
import { importar, importarXml } from "./importar.js";
import { calcSN, receitaDaNota, periodoRBT12 } from "./simples.js";

const VERSAO = "1.0.15";   // igual ao versao.txt
const agora = () => new Date().toISOString();
const hojeMG = () => N.dh(new Date()).slice(0, 10);
const json = (dados, status = 200, extra = {}) => new Response(JSON.stringify(dados), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...extra } });
class Erro extends Error { constructor(msg, status = 400) { super(msg); this.status = status; } }
const enc = new TextEncoder();
const hex = b => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join("");
const b64 = b => btoa(String.fromCharCode(...new Uint8Array(b)));
const unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));

// ---------------------------------------------------------------- segurança
async function hashSenha(senha, sal) {
  const k = await crypto.subtle.importKey("raw", enc.encode(senha), "PBKDF2", false, ["deriveBits"]);
  return hex(await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: enc.encode(sal), iterations: 100000 }, k, 256));
}
async function chaveMestra(env) {
  if (!env.CHAVE_MESTRA || env.CHAVE_MESTRA.length < 16) throw new Erro("Servidor sem CHAVE_MESTRA configurada (wrangler secret put CHAVE_MESTRA).", 500);
  return crypto.subtle.importKey("raw", await crypto.subtle.digest("SHA-256", enc.encode(env.CHAVE_MESTRA)), "AES-GCM", false, ["encrypt", "decrypt"]);
}
async function cifrar(env, texto) { const iv = crypto.getRandomValues(new Uint8Array(12)); const c = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, await chaveMestra(env), enc.encode(texto)); return b64(iv) + "." + b64(c); }
async function decifrar(env, s) { const [iv, c] = s.split("."); return new TextDecoder().decode(await crypto.subtle.decrypt({ name: "AES-GCM", iv: unb64(iv) }, await chaveMestra(env), unb64(c))); }
const cookie = req => Object.fromEntries((req.headers.get("cookie") || "").split(";").map(p => p.trim().split("=")).filter(p => p[0]));

async function sessao(req, env) {
  const t = cookie(req).s; if (!t) return null;
  const r = await env.DB.prepare("SELECT c.*, s.emp_conta FROM sessoes s JOIN contas c ON c.id=s.conta_id WHERE s.token=? AND s.expira>?").bind(t, agora()).first();
  return r || null;
}
function licencaOk(conta) { return conta.papel === "admin" || (conta.status === "ativo" && !!conta.valido_ate && conta.valido_ate >= hojeMG()); }

// ---------------------------------------------------------------- ajudantes de dados
const CAMPOS_EMP = ["cnpj", "ie", "razao_social", "fantasia", "logradouro", "numero", "complemento", "bairro", "codigo_municipio", "municipio", "uf", "cep", "telefone", "ambiente", "serie", "crt", "p_cred_sn", "ibs_sn", "p_ibs_sn", "p_cbs_sn", "p_cred_em", "rbt12", "anexo_sn", "rbt_auto"];
const CAMPOS_CLI = ["nome", "documento", "ie", "indicador_ie", "email", "telefone", "cep", "logradouro", "numero", "complemento", "bairro", "codigo_municipio", "municipio", "uf"];
const CAMPOS_PROD = ["codigo", "descricao", "ncm", "cest", "ean", "unidade", "preco", "origem", "csosn", "pis_cst", "mva", "p_icms_st", "p_fcp_st", "c_ativ_sn", "cst_ibs", "cclass_trib", "cst_icms", "p_icms", "p_red_bc", "cfop"];
async function empresa(env, conta) {
  // O administrador pode "entrar" na empresa de um cliente (escolhida na Administração) para emitir por ela.
  if (conta.papel === "admin" && conta.emp_conta) { const x = await env.DB.prepare("SELECT * FROM empresas WHERE conta_id=?").bind(conta.emp_conta).first(); if (x) return x; }
  let e = await env.DB.prepare("SELECT * FROM empresas WHERE conta_id=?").bind(conta.id).first();
  if (!e) { await env.DB.prepare("INSERT INTO empresas (conta_id, atualizado_em) VALUES (?,?)").bind(conta.id, agora()).run(); e = await env.DB.prepare("SELECT * FROM empresas WHERE conta_id=?").bind(conta.id).first(); }
  return e;
}
// RBT12 automático: na virada do mês soma as vendas autorizadas (produção) dos 12 meses anteriores e recalcula as alíquotas.
// Data/hora de emissão informada pelo usuário: a SEFAZ aceita até 5 minutos à frente e até 30 dias para trás.
function dhEmissao(v) {
  if (!v) return null; const t = new Date(v).getTime();
  if (isNaN(t)) throw new Erro("Data ou hora de emissão inválida.");
  if (t > Date.now() + 5 * 60e3) throw new Erro("A data/hora de emissão não pode ser no futuro.");
  if (t < Date.now() - 30 * 864e5) throw new Erro("A data de emissão não pode ser de mais de 30 dias atrás.");
  return v;
}
async function somaRBT12(env, emp, mes) {
  const { ini, fim } = periodoRBT12(mes);
  const r = (await env.DB.prepare("SELECT dados, total, substr(dh_emissao,1,7) m FROM notas WHERE empresa_id=? AND ambiente='1' AND situacao='AUTORIZADA' AND substr(dh_emissao,1,7)>=? AND substr(dh_emissao,1,7)<?").bind(emp.id, ini, fim).all()).results;
  const meses = new Set(r.map(x => x.m)); let total = 0; for (const x of r) total += receitaDaNota(x.dados, x.total);
  return { rbt12: Math.round(total * 100) / 100, notas: r.length, meses: meses.size, ini, fim };
}
async function atualizarRBT12(env, emp, forcar) {
  const mes = hojeMG().slice(0, 7);
  if (!["1", "2"].includes(emp.crt) || String(emp.rbt_auto ?? "1") !== "1" || (!forcar && emp.rbt_mes === mes)) return emp;
  const s = await somaRBT12(env, emp, mes);
  if (!s.notas) { await env.DB.prepare("UPDATE empresas SET rbt_mes=? WHERE id=?").bind(mes, emp.id).run(); return { ...emp, rbt_mes: mes }; }
  const c = calcSN(emp.anexo_sn, s.rbt12) || {}, v = { rbt12: String(s.rbt12), rbt_mes: mes, rbt_meses: String(s.meses), p_cred_em: emp.crt === "1" ? mes : emp.p_cred_em };
  if (!c.erro && c.faixa) Object.assign(v, { p_cred_sn: String(c.icms), p_ibs_sn: String(c.ibs), p_cbs_sn: String(c.cbs) });
  await env.DB.prepare(`UPDATE empresas SET ${Object.keys(v).map(k => k + "=?").join(",")} WHERE id=?`).bind(...Object.values(v), emp.id).run();
  return { ...emp, ...v };
}
const publicaEmp = e => { const { chave_cifrada, cert_pem, ...r } = e; r.tem_certificado = !!chave_cifrada; return r; };
function limiteMEI(ano) { return ano <= 2026 ? 81000 : ano === 2027 ? 110000 : 140000; }
async function atualizarNota(env, chave, campos) {
  const k = Object.keys(campos); if (!k.length) return;
  await env.DB.prepare(`UPDATE notas SET ${k.map(x => x + "=?").join(",")}, atualizada_em=? WHERE chave=?`).bind(...k.map(x => campos[x]), agora(), chave).run();
}

// ---------------------------------------------------------------- SEFAZ
function transporte(env, emp) {
  const f = env["CERT_" + emp.id];
  if (!f || typeof f.fetch !== "function")
    throw new Erro(emp.mtls_id ? "Certificado enviado, mas ainda não ativado no servidor. Aguarde o administrador ativar (leva poucos minutos)."
      : "Envie o certificado digital A1 em Empresa → Certificado.");
  return f;
}
async function chaveRSA(env, emp) { if (!emp.chave_cifrada) throw new Erro("Envie o certificado digital A1 em Empresa → Certificado."); return N.importarChave(await decifrar(env, emp.chave_cifrada)); }
const espera = ms => new Promise(r => setTimeout(r, ms));

async function registrarProt(env, chave, assinada, prot) {
  const p = N.lerProt(prot); if (p.chave !== chave) throw new Error("Protocolo recebido para outra chave.");
  const situacao = N.situacaoProt(p.cStat);
  const proc = ["AUTORIZADA", "DENEGADA"].includes(situacao) ? N.montarProc(assinada, prot) : null;
  await atualizarNota(env, chave, { situacao, cstat: p.cStat, motivo: p.xMotivo, protocolo: p.nProt, xml_autorizado: proc });
  return { situacao, chave, cstat: p.cStat, motivo: p.xMotivo, protocolo: p.nProt };
}
async function consultarRecibo(env, f, chave, recibo, amb, assinada) {
  for (let n = 0; n < 6; n++) {
    await espera(n ? 2000 : 1000);
    const resp = await N.chamarSefaz(f, "retautorizacao", amb, N.consReci(amb, recibo)), ret = N.bloco(resp, "retConsReciNFe");
    const c = N.tag(ret, "cStat"); if (c === "105") continue;
    const prot = N.bloco(ret, "protNFe"); if (c === "104" && prot) return registrarProt(env, chave, assinada, prot);
    await atualizarNota(env, chave, { situacao: "REJEITADA", cstat: c, motivo: N.tag(ret, "xMotivo") });
    return { situacao: "REJEITADA", chave, cstat: c, motivo: N.tag(ret, "xMotivo") };
  }
  return { situacao: "INDETERMINADA", chave, cstat: "105", motivo: "Lote em processamento. Use 'Consultar situação' em instantes." };
}

async function emitir(env, conta, emp, corpo) {
  if (!licencaOk(conta)) throw new Erro("Licença vencida ou conta bloqueada. Renove para emitir.", 402);
  const f = transporte(env, emp), chave = await chaveRSA(env, emp);
  const cli = await env.DB.prepare("SELECT * FROM clientes WHERE id=? AND empresa_id=?").bind(+corpo.cliente_id, emp.id).first();
  if (!cli) throw new Erro("Escolha o destinatário.");
  const amb = emp.ambiente === "1" ? "1" : "2", rid = corpo.rascunho_id ? +corpo.rascunho_id : null;
  if (rid) {
    const pend = await env.DB.prepare("SELECT chave FROM notas WHERE empresa_id=? AND rascunho_id=? AND situacao IN ('INDETERMINADA','ENVIANDO','AUTORIZADA','CANCELADA','DENEGADA') LIMIT 1").bind(emp.id, rid).first();
    if (pend) throw new Erro(`Este rascunho já tem NF-e autorizada ou com envio pendente (chave ${pend.chave}). Consulte a situação antes de emitir de novo.`);
  }
  const reuso = rid ? await env.DB.prepare("SELECT numero, serie FROM notas WHERE empresa_id=? AND rascunho_id=? AND ambiente=? AND situacao='REJEITADA' ORDER BY id DESC LIMIT 1").bind(emp.id, rid, amb).first() : null;
  const col = amb === "1" ? "proximo_numero" : "proximo_homolog";
  let numero;
  if (reuso && +reuso.serie === +emp.serie) numero = +reuso.numero;
  else numero = (await env.DB.prepare(`UPDATE empresas SET ${col}=${col}+1 WHERE id=? RETURNING ${col}-1 AS n`).bind(emp.id).first()).n;
  const montada = N.montarNFe({ emitente: emp, destinatario: cli, itens: corpo.itens || [], natureza: corpo.natureza, serie: emp.serie, numero, ambiente: amb,
    ind_final: corpo.ind_final ?? "1", ind_pres: corpo.ind_pres || "1", pagamentos: [[corpo.pagamento || "01", null]], info: corpo.info, fin_nfe: corpo.fin_nfe || "1",
    referencias: corpo.referencias || [], transporte: corpo.transporte, dh_saida: corpo.dh_saida || null, dh_emissao: dhEmissao(corpo.dh_emissao), versao: VERSAO });
  const assinada = await N.assinarNFe(montada, chave, emp.cert_pem);
  const i = montada.info;
  await env.DB.prepare("DELETE FROM notas WHERE empresa_id=? AND ambiente=? AND serie=? AND numero=? AND situacao='REJEITADA'").bind(emp.id, amb, i.serie, i.numero).run();
  await env.DB.prepare("INSERT INTO notas (empresa_id, rascunho_id, ambiente, serie, numero, chave, situacao, dh_emissao, total, destinatario, dados, xml_assinado, criada_em, atualizada_em) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
    .bind(emp.id, rid, amb, i.serie, i.numero, i.chave, "ENVIANDO", i.dhEmi, i.vNF, cli.nome, JSON.stringify({ ...corpo, cliente: cli }), assinada, agora(), agora()).run();
  let ret;
  try {
    let resp = await N.chamarSefaz(f, "autorizacao", amb, N.lote(assinada, true)); ret = N.bloco(resp, "retEnviNFe");
    if (!ret) throw new Error("Resposta sem retEnviNFe.");
    if (N.tag(ret, "cStat") === "452") { resp = await N.chamarSefaz(f, "autorizacao", amb, N.lote(assinada, false)); ret = N.bloco(resp, "retEnviNFe"); }
  } catch (e) {
    await atualizarNota(env, i.chave, { situacao: "INDETERMINADA", motivo: String(e.message || e).slice(0, 300) });
    return { situacao: "INDETERMINADA", chave: i.chave, motivo: "Sem resposta confirmada da SEFAZ. Use 'Consultar situação' antes de reenviar." };
  }
  const c = N.tag(ret, "cStat"), m = N.tag(ret, "xMotivo"), prot = N.bloco(ret, "protNFe");
  let res;
  if (c === "104" && prot) res = await registrarProt(env, i.chave, assinada, prot);
  else if (c === "103") { const rec = N.tag(ret, "nRec"); await atualizarNota(env, i.chave, { situacao: "INDETERMINADA", recibo: rec, cstat: c, motivo: m }); res = await consultarRecibo(env, f, i.chave, rec, amb, assinada); }
  else { await atualizarNota(env, i.chave, { situacao: "REJEITADA", cstat: c, motivo: m }); res = { situacao: "REJEITADA", chave: i.chave, cstat: c, motivo: m }; }
  if (rid && res.situacao === "AUTORIZADA") await env.DB.prepare("DELETE FROM rascunhos WHERE id=? AND empresa_id=?").bind(rid, emp.id).run();
  return res;
}

async function consultar(env, emp, chave) {
  const nota = await env.DB.prepare("SELECT * FROM notas WHERE chave=? AND empresa_id=?").bind(chave, emp.id).first(); if (!nota) throw new Erro("Nota não encontrada.", 404);
  const f = transporte(env, emp), resp = await N.chamarSefaz(f, "consulta", nota.ambiente, N.consSit(nota.ambiente, chave)), ret = N.bloco(resp, "retConsSitNFe");
  const c = N.tag(ret, "cStat"), m = N.tag(ret, "xMotivo"), prot = N.bloco(ret, "protNFe");
  if (["100", "150", "110", "301", "302"].includes(c) && prot) return registrarProt(env, chave, nota.xml_assinado, prot);
  if (["101", "151", "155"].includes(c)) { await atualizarNota(env, chave, { situacao: "CANCELADA", cstat: c, motivo: m }); return { situacao: "CANCELADA", chave, cstat: c, motivo: m }; }
  if (c === "217" && ["INDETERMINADA", "ENVIANDO"].includes(nota.situacao)) { await atualizarNota(env, chave, { situacao: "REJEITADA", cstat: c, motivo: "Não recebida pela SEFAZ (217); pode reenviar." }); return { situacao: "REJEITADA", chave, cstat: c, motivo: m }; }
  return { situacao: nota.situacao, chave, cstat: c, motivo: m };
}
async function enviarEvento(env, emp, nota, tipo, seq, texto, montar) {
  const f = transporte(env, emp), { ev, corpo } = await montar({ chave: nota.chave, ambiente: nota.ambiente, chaveRSA: await chaveRSA(env, emp), certPem: emp.cert_pem });
  const r = N.lerRetEvento(await N.chamarSefaz(f, "evento", nota.ambiente, corpo), ev);
  await env.DB.prepare("INSERT OR REPLACE INTO eventos (chave, tipo, seq, cstat, motivo, protocolo, texto, xml, criado_em) VALUES (?,?,?,?,?,?,?,?,?)").bind(nota.chave, tipo, seq, r.cStat, r.xMotivo, r.nProt || null, texto, r.proc || null, agora()).run();
  return r;
}

// ---------------------------------------------------------------- Cloudflare mTLS (certificado do cliente)
async function enviarMtls(env, emp, certPem, keyPem) {
  if (!env.CF_API_TOKEN || !env.CF_ACCOUNT_ID) return null;
  const r = await fetch(`https://api.cloudflare.com/client/v4/accounts/${env.CF_ACCOUNT_ID}/mtls_certificates`, { method: "POST",
    headers: { Authorization: "Bearer " + env.CF_API_TOKEN, "content-type": "application/json" },
    body: JSON.stringify({ ca: false, certificates: certPem, private_key: keyPem, name: `nfepro-empresa-${emp.id}-${Date.now()}` }) });
  const j = await r.json().catch(() => ({}));
  if (!j.success) throw new Erro("A Cloudflare recusou o certificado: " + ((j.errors || []).map(e => e.message).join("; ") || r.status));
  return j.result.id;
}


// ---------------------------------------------------------------- licença (mesmo servidor do NFE Pro Windows: nfspro.com.br)
const LIC_SERVIDOR = env => (env.LICENCA_SERVIDOR && env.LICENCA_SERVIDOR !== "desligado" ? env.LICENCA_SERVIDOR : "https://nfspro.com.br").replace(/\/$/, "");
const LIC_CHAVE = env => env.LICENCA_CHAVE || "yAt22nBvZdzWwy7S2m5jk8x1Om6cDHKQTkJrkeNde3A";
const b64url = s => Uint8Array.from(atob(s.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - (s.length % 4)) % 4)), c => c.charCodeAt(0));
// No PC (testar_no_pc.bat) o código é do COMPUTADOR: outra conta ou reinstalação no mesmo PC não ganha outro teste grátis.
// Hospedado, o código é da conta (e o teste grátis exige o CNPJ da empresa).
async function codigoLicenca(env, conta) { return hex(await crypto.subtle.digest("SHA-256", enc.encode(env.PC_ID ? "nfepro-web-pc:" + env.PC_ID : "nfepro-web:" + (env.CHAVE_MESTRA || "") + ":" + conta.id))).slice(0, 24).toUpperCase(); }
async function lerSerial(env, serial, codigo) {
  const [pre, pl, sg] = String(serial || "").split("."); if (pre !== "GS1" || !pl || !sg) return null;
  const chave = await crypto.subtle.importKey("raw", b64url(LIC_CHAVE(env)), { name: "Ed25519" }, false, ["verify"]);
  const bytes = b64url(pl); if (!(await crypto.subtle.verify({ name: "Ed25519" }, chave, b64url(sg), bytes))) return null;
  const d = JSON.parse(new TextDecoder().decode(bytes)); return d.product === "GLEISON-EMISSOR" && d.device === codigo && /^\d{4}-\d{2}-\d{2}$/.test(d.expires) ? d : null;
}
async function tabelaLicenca(env) { await env.DB.prepare("CREATE TABLE IF NOT EXISTS licencas (conta_id INTEGER PRIMARY KEY, codigo TEXT, rev INTEGER DEFAULT 0, expira TEXT, verificado_em TEXT)").run(); }
async function aplicarSerial(env, conta, serial, codigo) {
  const d = await lerSerial(env, serial, codigo); if (!d) return { ok: false, motivo: "Liberação inválida" };
  await tabelaLicenca(env);
  const atual = await env.DB.prepare("SELECT * FROM licencas WHERE conta_id=?").bind(conta.id).first();
  const rev = +(d.rev || 0);
  if (atual && rev <= +(atual.rev || 0) && atual.expira === d.expires) return { ok: false, motivo: "Licença já está atualizada", expira: d.expires };
  if (atual && rev < +(atual.rev || 0)) return { ok: false, motivo: "Licença já está atualizada", expira: atual.expira };
  await env.DB.prepare("INSERT OR REPLACE INTO licencas (conta_id, codigo, rev, expira, verificado_em) VALUES (?,?,?,?,?)").bind(conta.id, codigo, rev, d.expires, agora()).run();
  await env.DB.prepare("UPDATE contas SET valido_ate=? WHERE id=?").bind(d.expires, conta.id).run();
  return { ok: true, expira: d.expires };
}
async function verificarLicenca(env, conta) {
  const codigo = await codigoLicenca(env, conta);
  const r = await fetch(`${LIC_SERVIDOR(env)}/gsef/api/licenca?d=${codigo}`, { headers: { accept: "application/json" } });
  if (!r.ok) throw new Erro("Servidor de licença indisponível (" + r.status + ").", 502);
  const j = await r.json(); if (!j.serial) return { ok: false, motivo: "Nenhuma liberação encontrada ainda" };
  return aplicarSerial(env, conta, j.serial, codigo);
}

// ---------------------------------------------------------------- rotas
async function api(req, env, url) {
  const p = url.pathname.replace(/^\/api/, ""), m = req.method;
  if (m !== "GET" && req.headers.get("x-nfepro") !== "1") throw new Erro("Pedido inválido.", 403);   // proteção CSRF
  const corpo = m === "GET" ? {} : await req.json().catch(() => ({}));
  if (p === "/entrar" && m === "POST") {
    const email = String(corpo.email || "").trim().toLowerCase();
    const c = await env.DB.prepare("SELECT * FROM contas WHERE email=?").bind(email).first();
    if (!c || (await hashSenha(String(corpo.senha || ""), c.sal)) !== c.senha) throw new Erro("E-mail ou senha incorretos.", 401);
    if (c.status === "bloqueado") throw new Erro("Conta bloqueada. Fale com o suporte.", 403);
    const t = hex(crypto.getRandomValues(new Uint8Array(32)));
    await env.DB.prepare("INSERT INTO sessoes (token, conta_id, expira) VALUES (?,?,?)").bind(t, c.id, new Date(Date.now() + 30 * 864e5).toISOString()).run();
    return json({ ok: true }, 200, { "set-cookie": `s=${t}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${30 * 86400}` });
  }
  if (p === "/cadastro" && m === "POST") {
    const email = String(corpo.email || "").trim().toLowerCase(), senha = String(corpo.senha || "");
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new Erro("E-mail inválido.");
    if (senha.length < 8) throw new Erro("A senha precisa ter pelo menos 8 caracteres.");
    if (await env.DB.prepare("SELECT 1 FROM contas WHERE email=?").bind(email).first()) throw new Erro("Este e-mail já tem cadastro. Use Entrar.");
    const admin = email === String(env.ADMIN_EMAIL || "").toLowerCase(), sal = hex(crypto.getRandomValues(new Uint8Array(16)));
    const dias = +(env.DIAS_TESTE || 0), validade = dias > 0 && env.LICENCA_SERVIDOR === "desligado" ? N.dh(new Date(Date.now() + dias * 864e5)).slice(0, 10) : null;
    await env.DB.prepare("INSERT INTO contas (email, nome, senha, sal, papel, status, valido_ate, criado_em) VALUES (?,?,?,?,?,?,?,?)")
      .bind(email, String(corpo.nome || "").slice(0, 80), await hashSenha(senha, sal), sal, admin ? "admin" : "cliente", "ativo", admin ? null : validade, agora()).run();
    return api(new Request(req.url, { method: "POST", headers: req.headers, body: JSON.stringify({ email, senha }) }), env, new URL(url.origin + "/api/entrar"));
  }
  const conta = await sessao(req, env); if (!conta) throw new Erro("Entre com seu e-mail e senha.", 401);
  if (p === "/sair") { await env.DB.prepare("DELETE FROM sessoes WHERE token=?").bind(cookie(req).s).run(); return json({ ok: true }, 200, { "set-cookie": "s=; Path=/; Max-Age=0" }); }
  let emp = await empresa(env, conta);
  if (p === "/eu" || p === "/emitir") emp = await atualizarRBT12(env, emp);
  if (p === "/rbt12" && m === "POST") return json({ ...(await somaRBT12(env, emp, hojeMG().slice(0, 7))), empresa: publicaEmp(await atualizarRBT12(env, emp, true)) });
  if (p === "/eu") {
    const ano = +hojeMG().slice(0, 4), mes = hojeMG().slice(0, 7);
    const fat = await env.DB.prepare("SELECT COALESCE(SUM(CASE WHEN substr(dh_emissao,1,7)=? THEN CAST(total AS REAL) END),0) mes, COALESCE(SUM(CAST(total AS REAL)),0) ano, COUNT(*) qtd FROM notas WHERE empresa_id=? AND ambiente='1' AND situacao='AUTORIZADA' AND substr(dh_emissao,1,4)=?").bind(mes, emp.id, String(ano)).first();
    let acessando = null;
    if (conta.papel === "admin" && conta.emp_conta) acessando = await env.DB.prepare("SELECT id, email, nome, status, valido_ate FROM contas WHERE id=?").bind(conta.emp_conta).first();
    return json({ acessando, conta: { email: conta.email, nome: conta.nome, papel: conta.papel, valido_ate: conta.valido_ate, licenca_ok: licencaOk(conta) }, empresa: publicaEmp(emp), faturamento: { ...fat, limite: limiteMEI(ano) }, versao: VERSAO, suporte: env.SUPORTE || "" });
  }
  if (p === "/empresa" && m === "POST") {
    const v = CAMPOS_EMP.map(k => k === "serie" ? Math.max(0, Math.min(999, +corpo[k] || 1)) : k === "ambiente" ? (corpo[k] === "1" ? "1" : "2")
      : k === "crt" ? (["1", "2"].includes(corpo[k]) ? corpo[k] : "4") : k === "p_cred_em" ? (corpo.crt === "1" ? new Date(Date.now() - 3 * 3600e3).toISOString().slice(0, 7) : "") : k === "rbt_auto" ? (corpo[k] === "0" ? "0" : "1") : k === "anexo_sn" ? (corpo[k] === "II" ? "II" : "I") : k === "rbt12" ? String(Math.max(0, +String(corpo[k] ?? "").replace(",", ".") || 0) || "") : k === "ibs_sn" ? (["0", "1"].includes(corpo[k]) ? corpo[k] : "A") : ["p_ibs_sn", "p_cbs_sn"].includes(k) ? String(Math.max(0, Math.min(30, +String(corpo[k] ?? "0").replace(",", ".") || 0))) : k === "p_cred_sn" ? String(Math.max(0, Math.min(10, +String(corpo[k] ?? "0").replace(",", ".") || 0))) : String(corpo[k] ?? "").trim());
    if (N.dig(corpo.cnpj).length !== 14) throw new Erro("CNPJ inválido.");
    await env.DB.prepare(`UPDATE empresas SET ${CAMPOS_EMP.map(k => k + "=?").join(",")}, atualizado_em=? WHERE id=?`).bind(...v, agora(), emp.id).run();
    if (corpo.proximo_numero && +corpo.proximo_numero > 0) await env.DB.prepare(`UPDATE empresas SET ${corpo.ambiente === "1" ? "proximo_numero" : "proximo_homolog"}=? WHERE id=?`).bind(+corpo.proximo_numero, emp.id).run();
    return json({ ok: true });
  }
  if (p === "/certificado" && m === "POST") {
    const certPem = String(corpo.cert_pem || ""), keyPem = String(corpo.key_pem || "");
    if (!/BEGIN CERTIFICATE/.test(certPem) || !/BEGIN PRIVATE KEY/.test(keyPem)) throw new Erro("Certificado inválido.");
    const k = await N.importarChave(keyPem).catch(() => { throw new Erro("Chave do certificado inválida."); });
    void k;
    const mtls = await enviarMtls(env, emp, certPem, keyPem);
    await env.DB.prepare("UPDATE empresas SET cert_pem=?, chave_cifrada=?, cert_nome=?, cert_validade=?, mtls_id=?, atualizado_em=? WHERE id=?")
      .bind(certPem, await cifrar(env, keyPem), String(corpo.nome || "").slice(0, 120), String(corpo.validade || "").slice(0, 10), mtls, agora(), emp.id).run();
    return json({ ok: true, mtls_id: mtls, ativo: !!env["CERT_" + emp.id] });
  }
  for (const [rota, tabela, campos] of [["/clientes", "clientes", CAMPOS_CLI], ["/produtos", "produtos", CAMPOS_PROD]]) {
    if (p === rota && m === "GET") return json((await env.DB.prepare(`SELECT * FROM ${tabela} WHERE empresa_id=? ORDER BY ${tabela === "clientes" ? "nome" : "codigo"}`).bind(emp.id).all()).results);
    if (p === rota && m === "POST") {
      const v = campos.map(k => String(corpo[k] ?? "").trim());
      if (!v[tabela === "clientes" ? 0 : 1]) throw new Erro(tabela === "clientes" ? "Informe o nome." : "Informe a descrição.");
      if (corpo.id) await env.DB.prepare(`UPDATE ${tabela} SET ${campos.map(k => k + "=?").join(",")} WHERE id=? AND empresa_id=?`).bind(...v, +corpo.id, emp.id).run();
      else await env.DB.prepare(`INSERT INTO ${tabela} (empresa_id, ${campos.join(",")}) VALUES (?, ${campos.map(() => "?").join(",")})`).bind(emp.id, ...v).run();
      return json({ ok: true });
    }
    if (p === rota + "/excluir" && m === "POST") { await env.DB.prepare(`DELETE FROM ${tabela} WHERE id=? AND empresa_id=?`).bind(+corpo.id, emp.id).run(); return json({ ok: true }); }
  }
  if (p === "/rascunhos" && m === "GET") return json((await env.DB.prepare("SELECT id, dados, atualizado_em FROM rascunhos WHERE empresa_id=? ORDER BY atualizado_em DESC").bind(emp.id).all()).results);
  if (p === "/rascunhos" && m === "POST") {
    const d = JSON.stringify(corpo.dados || {});
    if (corpo.id) { await env.DB.prepare("UPDATE rascunhos SET dados=?, atualizado_em=? WHERE id=? AND empresa_id=?").bind(d, agora(), +corpo.id, emp.id).run(); return json({ id: +corpo.id }); }
    return json({ id: (await env.DB.prepare("INSERT INTO rascunhos (empresa_id, dados, atualizado_em) VALUES (?,?,?) RETURNING id").bind(emp.id, d, agora()).first()).id });
  }
  if (p === "/rascunhos/excluir" && m === "POST") { await env.DB.prepare("DELETE FROM rascunhos WHERE id=? AND empresa_id=?").bind(+corpo.id, emp.id).run(); return json({ ok: true }); }
  if (p === "/notas" && m === "GET") {
    const de = url.searchParams.get("de") || "0000", ate = (url.searchParams.get("ate") || "9999") + "~", sit = url.searchParams.get("situacao") || "";
    const r = await env.DB.prepare(`SELECT id, ambiente, serie, numero, chave, situacao, cstat, motivo, protocolo, dh_emissao, total, destinatario FROM notas WHERE empresa_id=? AND dh_emissao>=? AND dh_emissao<=? ${sit ? "AND situacao=?" : ""} ORDER BY dh_emissao DESC LIMIT 500`).bind(...[emp.id, de, ate, sit].filter((x, i) => i < 3 || x)).all();
    return json(r.results);
  }
  if (p === "/licenca" && m === "GET") {
    const codigo = await codigoLicenca(env, conta); let info = null;
    try { const r = await fetch(`${LIC_SERVIDOR(env)}/gsef/api/info`); if (r.ok) { const j = await r.json(); info = { ativo: j.ativo, valor: j.valor, dias_teste: j.dias_teste, dias_pagamento: j.dias_pagamento }; } } catch { /* sem internet */ }
    await tabelaLicenca(env); const teve = await env.DB.prepare("SELECT 1 FROM licencas WHERE conta_id=?").bind(conta.id).first();
    const q = new URLSearchParams({ d: codigo, cnpj: N.dig(emp.cnpj), nome: (emp.razao_social || conta.email) + " (web)" });
    return json({ codigo, valido_ate: conta.valido_ate, ok: licencaOk(conta), info, primeira: !teve && !conta.valido_ate, automatico: !!env.PC_ID || N.dig(emp.cnpj).length === 14, pagar_url: `${LIC_SERVIDOR(env)}/gsef/pagar?${q}` });
  }
  if (p === "/licenca/verificar" && m === "POST") return json(await verificarLicenca(env, conta));
  if (p === "/licenca/teste" && m === "POST") {
    if (!env.PC_ID && N.dig(emp.cnpj).length !== 14) throw new Erro("Cadastre o CNPJ da empresa antes de ativar o teste grátis.");
    const codigo = await codigoLicenca(env, conta);
    const r = await fetch(`${LIC_SERVIDOR(env)}/gsef/api/teste`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ d: codigo, cnpj: N.dig(emp.cnpj), nome: (emp.razao_social || conta.email) + " (web)" }) });
    const j = await r.json().catch(() => ({})); if (!r.ok) throw new Erro(j.erro || "Não foi possível ativar o teste grátis.");
    return json(await aplicarSerial(env, conta, j.serial, codigo));
  }
  if (p === "/backup" && m === "GET") {   // backup completo da conta (sem a chave do certificado)
    const tudo = async (sql) => (await env.DB.prepare(sql).bind(emp.id).all()).results;
    const notas = await tudo("SELECT * FROM notas WHERE empresa_id=? ORDER BY id");
    const eventos = notas.length ? (await env.DB.prepare(`SELECT e.* FROM eventos e JOIN notas n ON n.chave=e.chave WHERE n.empresa_id=?`).bind(emp.id).all()).results : [];
    const { chave_cifrada, cert_pem, mtls_id, ...empresa } = emp;
    const dados = { formato: "nfepro-web-backup", versao: VERSAO, gerado_em: agora(), conta: conta.email, empresa,
      clientes: await tudo("SELECT * FROM clientes WHERE empresa_id=?"), produtos: await tudo("SELECT * FROM produtos WHERE empresa_id=?"),
      rascunhos: await tudo("SELECT * FROM rascunhos WHERE empresa_id=?"), notas, eventos };
    const nome = `NFE-Pro-Web_backup_${N.dig(emp.cnpj) || "empresa"}_${hojeMG()}.json`;
    return new Response(JSON.stringify(dados), { headers: { "content-type": "application/json; charset=utf-8", "content-disposition": `attachment; filename="${nome}"`, "cache-control": "no-store" } });
  }
  if (p === "/restaurar" && m === "POST") {   // restaura um backup do NFE Pro Web (em partes); não apaga nada, não duplica
    const R = { clientes: 0, produtos: 0, rascunhos: 0, notas: 0, eventos: 0, ignoradas: 0 }, cnpjEmp = N.dig(emp.cnpj);
    if (corpo.parte === "cadastro") {
      const e = corpo.empresa || {}, cnpj = N.dig(e.cnpj);
      if (cnpjEmp && cnpj && cnpj !== cnpjEmp) throw new Erro(`Este backup é de outro CNPJ (${cnpj}). A empresa desta conta é ${cnpjEmp}.`);
      if (!cnpjEmp && cnpj) await env.DB.prepare(`UPDATE empresas SET ${CAMPOS_EMP.map(k => k + "=?").join(",")}, atualizado_em=? WHERE id=?`).bind(...CAMPOS_EMP.map(k => e[k] ?? (k === "serie" ? 1 : k === "ambiente" ? "2" : k === "crt" ? "4" : k === "ibs_sn" ? "A" : k === "anexo_sn" ? "I" : k === "rbt_auto" ? "1" : ["p_cred_sn", "p_ibs_sn", "p_cbs_sn"].includes(k) ? "0" : "")), agora(), emp.id).run();
      await env.DB.prepare("UPDATE empresas SET proximo_numero=MAX(proximo_numero, ?), proximo_homolog=MAX(proximo_homolog, ?) WHERE id=?").bind(+e.proximo_numero || 1, +e.proximo_homolog || 1, emp.id).run();
      for (const [tab, campos, chaveDup] of [["clientes", CAMPOS_CLI, "nome"], ["produtos", CAMPOS_PROD, "codigo"]]) for (const r of corpo[tab] || []) {
        if (!r[chaveDup] || await env.DB.prepare(`SELECT 1 FROM ${tab} WHERE empresa_id=? AND ${chaveDup}=?`).bind(emp.id, r[chaveDup]).first()) continue;
        await env.DB.prepare(`INSERT INTO ${tab} (empresa_id, ${campos.join(",")}) VALUES (?, ${campos.map(() => "?").join(",")})`).bind(emp.id, ...campos.map(k => String(r[k] ?? ""))).run(); R[tab]++;
      }
      for (const r of corpo.rascunhos || []) { await env.DB.prepare("INSERT INTO rascunhos (empresa_id, dados, atualizado_em) VALUES (?,?,?)").bind(emp.id, String(r.dados || "{}"), r.atualizado_em || agora()).run(); R.rascunhos++; }
      return json(R);
    }
    const cols = ["ambiente", "serie", "numero", "chave", "situacao", "cstat", "motivo", "protocolo", "recibo", "dh_emissao", "total", "destinatario", "dados", "xml_assinado", "xml_autorizado", "criada_em", "atualizada_em"];
    for (const r of corpo.notas || []) {
      if (!/^\d{44}$/.test(r.chave || "") || (cnpjEmp && r.chave.slice(6, 20) !== cnpjEmp)) { R.ignoradas++; continue; }
      if (await env.DB.prepare("SELECT 1 FROM notas WHERE chave=?").bind(r.chave).first()) continue;
      await env.DB.prepare(`INSERT INTO notas (empresa_id, ${cols.join(",")}) VALUES (?, ${cols.map(() => "?").join(",")})`).bind(emp.id, ...cols.map(k => r[k] ?? null)).run(); R.notas++;
    }
    for (const e of corpo.eventos || []) {
      if (cnpjEmp && String(e.chave || "").slice(6, 20) !== cnpjEmp) continue;
      await env.DB.prepare("INSERT OR IGNORE INTO eventos (chave, tipo, seq, cstat, motivo, protocolo, texto, xml, criado_em) VALUES (?,?,?,?,?,?,?,?,?)").bind(e.chave, e.tipo, +e.seq || 1, e.cstat ?? null, e.motivo ?? null, e.protocolo ?? null, e.texto ?? null, e.xml ?? null, e.criado_em || agora()).run(); R.eventos++;
    }
    return json(R);
  }
  if (p === "/importar-xml" && m === "POST") { try { return json(await importarXml(env, emp, (corpo.arquivos || []).slice(0, 50).map(a => [String(a.nome || "arquivo").slice(0, 120), a.xml]))); } catch (e) { throw new Erro(e.message); } }
  if (p === "/importar" && m === "POST") { try { return json(await importar(env, await empresa(env, conta), corpo)); } catch (e) { throw new Erro(e.message); } }
  if (p === "/emitir" && m === "POST") return json(await emitir(env, conta, emp, corpo));
  if (p === "/consultar" && m === "POST") return json(await consultar(env, emp, String(corpo.chave || "")));
  if (p === "/status" && m === "POST") { const amb = emp.ambiente === "1" ? "1" : "2", ret = N.bloco(await N.chamarSefaz(transporte(env, emp), "status", amb, N.consStatus(amb)), "retConsStatServ"); return json({ cStat: N.tag(ret, "cStat"), xMotivo: N.tag(ret, "xMotivo") }); }
  if ((p === "/cancelar" || p === "/cce") && m === "POST") {
    const nota = await env.DB.prepare("SELECT * FROM notas WHERE chave=? AND empresa_id=?").bind(String(corpo.chave || ""), emp.id).first();
    if (!nota || nota.situacao !== "AUTORIZADA" || !nota.protocolo) throw new Erro(p === "/cancelar" ? "Somente NF-e autorizada pode ser cancelada." : "Carta de correção só para NF-e autorizada.");
    if (p === "/cancelar") {
      const r = await enviarEvento(env, emp, nota, "cancelamento", 1, corpo.justificativa, o => N.cancelamento({ ...o, protocolo: nota.protocolo, justificativa: corpo.justificativa }));
      if (r.ok) await atualizarNota(env, nota.chave, { situacao: "CANCELADA", cstat: r.cStat, motivo: r.xMotivo });
      return json(r);
    }
    const seq = ((await env.DB.prepare("SELECT MAX(seq) s FROM eventos WHERE chave=? AND tipo='cce' AND protocolo IS NOT NULL").bind(nota.chave).first())?.s || 0) + 1;
    if (seq > 20) throw new Erro("Limite de 20 cartas de correção por NF-e.");
    return json(await enviarEvento(env, emp, nota, "cce", seq, corpo.correcao, o => N.cartaCorrecao({ ...o, seq, correcao: corpo.correcao })));
  }
  // ---- administrador
  if (p.startsWith("/admin")) {
    if (conta.papel !== "admin") throw new Erro("Somente o administrador.", 403);
    if (p === "/admin/contas" && m === "GET") {
      const r = await env.DB.prepare("SELECT c.id, c.email, c.nome, c.papel, c.status, c.valido_ate, c.criado_em, e.id empresa_id, e.razao_social, e.fantasia, e.cnpj, e.municipio, e.uf, e.crt, e.ambiente, e.mtls_id, (SELECT COUNT(*) FROM notas n WHERE n.empresa_id=e.id AND n.situacao='AUTORIZADA') notas, (e.chave_cifrada IS NOT NULL) tem_cert FROM contas c LEFT JOIN empresas e ON e.conta_id=c.id ORDER BY c.criado_em DESC").all();
      return json(r.results.map(x => ({ ...x, cert_ativo: !!env["CERT_" + x.empresa_id] })));
    }
    if (p === "/admin/acessar" && m === "POST") {
      const alvo = corpo.conta_id ? await env.DB.prepare("SELECT id FROM contas WHERE id=?").bind(+corpo.conta_id).first() : null;
      if (corpo.conta_id && !alvo) throw new Erro("Conta não encontrada.");
      if (alvo) { const e = await env.DB.prepare("SELECT id FROM empresas WHERE conta_id=?").bind(alvo.id).first(); if (!e) await env.DB.prepare("INSERT INTO empresas (conta_id, atualizado_em) VALUES (?,?)").bind(alvo.id, agora()).run(); }
      await env.DB.prepare("UPDATE sessoes SET emp_conta=? WHERE token=?").bind(alvo && alvo.id !== conta.id ? alvo.id : null, cookie(req).s).run();
      return json({ ok: true });
    }
    if (p === "/admin/nova-conta" && m === "POST") {
      const email = String(corpo.email || "").trim().toLowerCase(), senha = String(corpo.senha || "");
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new Erro("E-mail inválido.");
      if (senha.length < 8) throw new Erro("A senha precisa ter pelo menos 8 caracteres.");
      if (await env.DB.prepare("SELECT id FROM contas WHERE email=?").bind(email).first()) throw new Erro("Já existe uma conta com este e-mail.");
      const sal = hex(crypto.getRandomValues(new Uint8Array(16))), dias = Math.max(0, Math.min(3650, +corpo.dias || 0));
      const val = dias ? N.dh(new Date(Date.now() + dias * 864e5)).slice(0, 10) : null;
      await env.DB.prepare("INSERT INTO contas (email, nome, senha, sal, papel, status, valido_ate, criado_em) VALUES (?,?,?,?,?,?,?,?)").bind(email, String(corpo.nome || "").slice(0, 80), await hashSenha(senha, sal), sal, "cliente", "ativo", val, agora()).run();
      const c = await env.DB.prepare("SELECT id FROM contas WHERE email=?").bind(email).first();
      await env.DB.prepare("INSERT INTO empresas (conta_id, razao_social, cnpj, atualizado_em) VALUES (?,?,?,?)").bind(c.id, String(corpo.nome || "").slice(0, 120), N.dig(corpo.cnpj || "").slice(0, 14) || null, agora()).run();
      return json({ ok: true, id: c.id });
    }
    if (p === "/admin/conta" && m === "POST") {
      await env.DB.prepare("UPDATE contas SET status=?, valido_ate=? WHERE id=? AND papel<>'admin'").bind(corpo.status === "bloqueado" ? "bloqueado" : "ativo", String(corpo.valido_ate || "").slice(0, 10) || null, +corpo.id).run();
      return json({ ok: true });
    }
  }
  throw new Erro("Rota não encontrada.", 404);
}

async function arquivo(req, env, url) {
  const conta = await sessao(req, env); if (!conta) return Response.redirect(url.origin + "/", 302);
  const emp = await empresa(env, conta), chave = url.pathname.split("/").pop();
  const nota = await env.DB.prepare("SELECT * FROM notas WHERE chave=? AND empresa_id=?").bind(chave, emp.id).first();
  if (!nota) return new Response("Nota não encontrada.", { status: 404 });
  if (url.pathname.startsWith("/xml/")) {
    const xml = nota.xml_autorizado || nota.xml_assinado, nome = `${(nota.destinatario || "Cliente").replace(/[\\/:*?"<>|]/g, "")} - NF ${nota.numero}.xml`;
    return new Response(xml, { headers: { "content-type": "application/xml; charset=utf-8", "content-disposition": `attachment; filename*=UTF-8''${encodeURIComponent(nome)}` } });
  }
  return new Response(danfeHTML(nota, emp), { headers: { "content-type": "text/html; charset=utf-8" } });
}

// Bancos criados antes da versão 1.0.14 ganham as colunas novas.
let migrado = false;
async function migrar(env) {
  if (migrado) return;
  for (const sql of ["ALTER TABLE empresas ADD COLUMN crt TEXT DEFAULT '4'", "ALTER TABLE empresas ADD COLUMN p_cred_sn TEXT DEFAULT '0'",
    "ALTER TABLE produtos ADD COLUMN mva TEXT DEFAULT '0'", "ALTER TABLE produtos ADD COLUMN p_icms_st TEXT DEFAULT '0'", "ALTER TABLE produtos ADD COLUMN p_fcp_st TEXT DEFAULT '0'",
    "ALTER TABLE empresas ADD COLUMN ibs_sn TEXT DEFAULT 'A'", "ALTER TABLE empresas ADD COLUMN p_ibs_sn TEXT DEFAULT '0'", "ALTER TABLE empresas ADD COLUMN p_cbs_sn TEXT DEFAULT '0'",
    "ALTER TABLE produtos ADD COLUMN c_ativ_sn TEXT DEFAULT '01'", "ALTER TABLE produtos ADD COLUMN cst_ibs TEXT DEFAULT '000'", "ALTER TABLE produtos ADD COLUMN cclass_trib TEXT DEFAULT '000001'",
    "ALTER TABLE empresas ADD COLUMN p_cred_em TEXT DEFAULT ''", "ALTER TABLE produtos ADD COLUMN cst_icms TEXT DEFAULT '00'",
    "ALTER TABLE produtos ADD COLUMN p_icms TEXT DEFAULT '0'", "ALTER TABLE produtos ADD COLUMN p_red_bc TEXT DEFAULT '0'",
    "ALTER TABLE empresas ADD COLUMN rbt12 TEXT DEFAULT ''", "ALTER TABLE empresas ADD COLUMN anexo_sn TEXT DEFAULT 'I'",
    "ALTER TABLE empresas ADD COLUMN rbt_auto TEXT DEFAULT '1'", "ALTER TABLE sessoes ADD COLUMN emp_conta INTEGER", "ALTER TABLE produtos ADD COLUMN cfop TEXT DEFAULT '5102'", "ALTER TABLE empresas ADD COLUMN rbt_mes TEXT DEFAULT ''", "ALTER TABLE empresas ADD COLUMN rbt_meses TEXT DEFAULT ''"])
    try { await env.DB.prepare(sql).run(); } catch { /* coluna já existe */ }
  migrado = true;
}
export default {
  async fetch(req, env) {
    await migrar(env);
    const url = new URL(req.url);
    try {
      if (url.pathname.startsWith("/api/")) return await api(req, env, url);
      if (/^\/(danfe|xml)\/\d{44}$/.test(url.pathname)) return await arquivo(req, env, url);
      return env.ASSETS ? env.ASSETS.fetch(req) : new Response("Não encontrado", { status: 404 });
    } catch (e) {
      const status = e instanceof Erro ? e.status : e instanceof N.ErroEmissao ? 422 : 500;
      if (status === 500) console.error(e);
      return json({ erro: status === 500 ? "Erro interno: " + String(e.message || e).slice(0, 200) : e.message }, status);
    }
  },
};
export { api as _api, hashSenha as _hashSenha };
