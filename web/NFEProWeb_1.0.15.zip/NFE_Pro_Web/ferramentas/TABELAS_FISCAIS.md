# Tabelas de sugestão do cadastro de produto

- `public/rtc_ncm.json`: NCM → cClassTrib (anexos da LC 214/2025) e descrição dos cClassTrib (IT 2025.002).
  Base: repositório ModelagemRTC — Copyright (c) 2025 André F. Moraes / DJSystem, licença MIT.
- `public/ncm.json`: tabela NCM vigente da Receita (Classif), com a descrição completa.
- `public/st_mg.json`: MVA da ST de MG por CEST (RICMS/MG 2023, Anexo VII, Parte 2). Base: icms-st-dados (Thiago Garofalo, MIT).
- `public/cest_ncm.json`: NCM → CEST (Convênio ICMS 142/2018, CONFAZ). Base: lumina76-fiscal-data (snapshot 28/09/2026).

Atualização automática: toda segunda-feira o GitHub Actions do repositório gs-ef-atualizacoes (tabelas/gerar.py) baixa a tabela
oficial da Calculadora de Tributos (RFB/CGIBS) e grava web/tabelas/*.json; o sistema lê de lá e, sem internet, usa estas cópias.

São só sugestões: o usuário confere o enquadramento do produto. Atualizar quando sair nova versão da tabela oficial.
