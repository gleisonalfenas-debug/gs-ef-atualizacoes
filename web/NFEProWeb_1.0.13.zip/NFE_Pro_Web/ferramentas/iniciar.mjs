// Abre o NFE Pro Web no PC: primeiro procura atualização (se houver internet), depois sobe o sistema.
// Se já houver um NFE Pro Web rodando e a atualização foi instalada, ele é desligado para abrir a versão nova.
import { atualizar } from "./atualizar.mjs";
let novo = false;
try {
  const r = await atualizar(); novo = r.atualizado;
  console.log(r.atualizado ? `\n  ✔ NFE Pro Web atualizado: ${r.anterior} → ${r.versao}\n` : `\n  Versão ${r.versao} (já é a mais recente)\n`);
} catch (e) { console.log(`\n  Não foi possível procurar atualização agora (${e.message}). Abrindo a versão atual.\n`); }
if (novo) { try { await fetch("http://127.0.0.1:8787/__sair", { signal: AbortSignal.timeout(2000) }); await new Promise(r => setTimeout(r, 1200)); } catch { /* não estava rodando */ } }
await import("../test/servidor_local.mjs?" + Date.now());
