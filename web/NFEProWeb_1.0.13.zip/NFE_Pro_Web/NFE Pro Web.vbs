Set sh = CreateObject("WScript.Shell")
Set fs = CreateObject("Scripting.FileSystemObject")
pasta = fs.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = pasta
If sh.Run("cmd /c where node", 0, True) <> 0 Then
  MsgBox "Instale o Node.js LTS (https://nodejs.org) e abra de novo.", 48, "NFE Pro Web"
  WScript.Quit
End If
' Abre sem a janela preta: procura atualizacao e abre o navegador (se ja estiver rodando, so abre o navegador;
' se tiver atualizacao, reinicia na versao nova). Registro em %TEMP%\nfepro_web_log_*.txt
Randomize
logArq = sh.ExpandEnvironmentStrings("%TEMP%") & "\nfepro_web_log_" & Int(Rnd * 1000000) & ".txt"
sh.Run "cmd /c node --experimental-sqlite --no-warnings ferramentas\iniciar.mjs > """ & logArq & """ 2>&1", 0, False
