// DANFE (modelo retrato A4, padrão do Manual de Orientação) em HTML — imprimir ou salvar em PDF pelo navegador.
const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const doc = d => (d = String(d || "").replace(/\D/g, "")).length === 14 ? d.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, "$1.$2.$3/$4-$5") : d.length === 11 ? d.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4") : d;
const cep = c => (c = String(c || "").replace(/\D/g, "")).length === 8 ? c.replace(/(\d{5})(\d{3})/, "$1-$2") : c;
const fone = f => (f = String(f || "").replace(/\D/g, "")).length >= 10 ? f.replace(/(\d{2})(\d{4,5})(\d{4})$/, "($1) $2-$3") : f;
const dt = s => s ? `${s.slice(8, 10)}/${s.slice(5, 7)}/${s.slice(0, 4)}` : "";
const hr = s => s ? s.slice(11, 19) : "";
const n2 = v => (+v || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const n4 = v => (+v || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 4 });
const P = ["212222","222122","222221","121223","121322","131222","122213","122312","132212","221213","221312","231212","112232","122132","122231","113222","123122","123221","223211","221132","221231","213212","223112","312131","311222","321122","321221","312212","322112","322211","212123","212321","232121","111323","131123","131321","112313","132113","132311","211313","231113","231311","112133","112331","132131","113123","113321","133121","313121","211331","231131","213113","213311","213131","311123","311321","331121","312113","312311","332111","314111","221411","431111","111224","111422","121124","121421","141122","141221","112214","112412","122114","122411","142112","142211","241211","221114","413111","241112","134111","111242","121142","121241","114212","124112","124211","411212","421112","421211","212141","214121","412121","111143","111341","131141","114113","114311","411113","411311","113141","114131","311141","411131","211412","211214","211232","2331112"];
export function code128c(d) {
  const cods = [105]; for (let i = 0; i < d.length; i += 2) cods.push(+d.slice(i, i + 2));
  cods.push(cods.reduce((s, c, i) => s + c * (i || 1), 0) % 103); cods.push(106);
  let x = 10, barras = ""; for (const c of cods) [...P[c]].forEach((w, i) => { if (i % 2 === 0) barras += `<rect x="${x}" y="0" width="${w}" height="50"/>`; x += +w; });
  return `<svg viewBox="0 0 ${x + 10} 50" preserveAspectRatio="none" style="width:100%;height:16mm;display:block">${barras}</svg>`;
}
const MODFRETE = { 0: "0 - Por conta do Remet", 1: "1 - Por conta do Dest", 2: "2 - Por conta de Terceiros", 3: "3 - Próprio Remet", 4: "4 - Próprio Dest", 9: "9 - Sem Frete" };
// célula: rótulo pequeno em cima, valor embaixo
const c = (rot, val, est = "", cls = "") => `<td class="${cls}" style="${est}"><span class="r">${rot}</span><span class="v">${val === "" || val === undefined || val === null ? "&nbsp;" : val}</span></td>`;
const T = (cols, linhas) => `<table class="q"><colgroup>${cols.map(w => `<col style="width:${w}%">`).join("")}</colgroup>${linhas.map(l => `<tr>${l}</tr>`).join("")}</table>`;

export function danfeHTML(nota, emp) {
  const d = JSON.parse(nota.dados || "{}"), cli = d.cliente || {}, itens = d.itens || [], ch = nota.chave, tr = d.transporte || {};
  const homolog = nota.ambiente === "2", cancelada = nota.situacao === "CANCELADA";
  const marca = cancelada ? "CANCELADA" : homolog ? "SEM VALOR FISCAL" : nota.situacao !== "AUTORIZADA" ? "SEM VALOR FISCAL" : "";
  const entrada = itens.length && "123".includes(String(itens[0].cfop || "5")[0]);
  const cfop = it => { const x = String(it.cfop || "5102"); return (entrada ? (cli.uf === "MG" ? "1" : "2") : (cli.uf === "MG" ? "5" : "6")) + x.slice(1); };
  const vProd = itens.reduce((s, i) => s + (+i.quantidade || 0) * (+i.preco || 0), 0), vFrete = itens.reduce((s, i) => s + (+i.frete || 0), 0), vDesc = itens.reduce((s, i) => s + (+i.desconto || 0), 0);
  const numero = String(nota.numero).padStart(9, "0").replace(/(\d{3})(\d{3})(\d{3})/, "$1.$2.$3");
  const end = r => `${esc(r.logradouro)}${r.numero ? ", " + esc(r.numero) : ""}${r.complemento ? " " + esc(r.complemento) : ""}`;
  const nomeDest = homolog ? "NF-E EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL" : cli.nome;
  const info = "DOCUMENTO EMITIDO POR MEI OPTANTE PELO SIMPLES NACIONAL. NAO GERA DIREITO A CREDITO FISCAL DE IPI." + (d.info ? " " + d.info : "");
  return `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><title>DANFE ${numero} - ${esc(cli.nome || "")}</title><style>
  @page{size:A4 portrait;margin:8mm}*{box-sizing:border-box}
  body{margin:0;background:#888;font:8pt "Times New Roman",Times,serif;color:#000}
  .folha{width:210mm;min-height:297mm;margin:8mm auto;background:#fff;padding:8mm;box-shadow:0 2px 12px rgba(0,0,0,.35);position:relative;display:flex;flex-direction:column}
  @media print{body{background:#fff}.folha{margin:0;width:100%;min-height:279mm;padding:0;box-shadow:none}.acoes{display:none}}
  .acoes{text-align:center;padding:8px}.acoes button{font:14px Arial;padding:6px 14px}
  table.q{width:100%;border-collapse:collapse;table-layout:fixed;margin-top:-0.3mm}
  table.q td{border:0.35mm solid #000;padding:0.6mm 1.2mm;vertical-align:top;overflow:hidden}
  .r{display:block;font-size:6.2pt;text-transform:uppercase;white-space:nowrap;overflow:hidden}
  .v{display:block;font-size:9pt;min-height:4.3mm;line-height:4.3mm;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .dir .v{text-align:right}.cen{text-align:center}
  .tit{font-size:7.5pt;font-weight:bold;margin:2mm 0 0.5mm;text-transform:uppercase}
  .marca{position:absolute;left:0;right:0;top:50%;transform:translateY(-50%) rotate(-28deg);text-align:center;font-size:54pt;white-space:nowrap;color:rgba(0,0,0,.13);pointer-events:none;letter-spacing:3px}
  .prod{flex:1;display:flex;flex-direction:column;min-height:60mm}.prod .caixa{flex:1;border:0.35mm solid #000;display:flex;flex-direction:column}
  table.it{width:100%;border-collapse:collapse;table-layout:fixed}table.it th,table.it td{border-right:0.35mm solid #000;padding:0.7mm 0.8mm;font-size:7.4pt;vertical-align:top}
  table.it th{font-size:6pt;font-weight:normal;text-transform:uppercase;border-bottom:0.35mm solid #000}table.it td.n{text-align:right;white-space:nowrap}
  table.it th:last-child,table.it td:last-child{border-right:0}.prod .resto{flex:1;display:flex}.prod .resto i{border-right:0.35mm solid #000}.prod .resto i:last-child{border-right:0}
  .tracejado{border-top:0.35mm dashed #000;margin:2mm 0}
  </style></head><body><div class="acoes"><button onclick="print()">Imprimir / Salvar em PDF</button></div><div class="folha">${marca ? `<div class="marca">${marca}</div>` : ""}
  ${T([80, 20], [c(`<span style="white-space:normal;display:block;font-size:6.4pt">RECEBEMOS DE ${esc(emp.razao_social)} OS PRODUTOS/SERVIÇOS CONSTANTES NA NOTA FISCAL INDICADA AO LADO. EMISSÃO: ${dt(nota.dh_emissao)} · VALOR TOTAL: R$ ${n2(nota.total)} · DESTINATÁRIO: ${esc(nomeDest)}</span>`, "", "white-space:normal") + `<td rowspan="2" class="cen" style="vertical-align:middle"><b style="font-size:14pt">NF-e</b><br><b>Nº ${numero}</b><br><b>SÉRIE: ${nota.serie}</b></td>`,
     `<td style="padding:0"><table class="q" style="margin:0"><colgroup><col style="width:25%"><col style="width:75%"></colgroup><tr>${c("Data de recebimento", "")}${c("Identificação e assinatura do recebedor", "")}</tr></table></td>`])}
  <div class="tracejado"></div>
  ${T([41, 18, 41], [`<td rowspan="3" style="vertical-align:middle;text-align:center;padding:1.5mm"><span class="r" style="text-align:left">Identificação do emitente</span><b style="font-size:11.5pt;display:block;margin:1.2mm 0">${esc(emp.razao_social)}</b>${end(emp)}<br>${esc(emp.bairro)} - ${cep(emp.cep)}<br>${esc(emp.municipio)} - ${esc(emp.uf)}${emp.telefone ? "<br>Fone: " + fone(emp.telefone) : ""}</td>
     <td rowspan="3" class="cen" style="vertical-align:middle"><b style="font-size:16pt">DANFE</b><br>DOCUMENTO AUXILIAR DA NOTA FISCAL ELETRÔNICA<div style="display:flex;align-items:center;justify-content:center;gap:2mm;margin:1mm 0">
     <span style="text-align:left">0 - ENTRADA<br>1 - SAÍDA</span><b style="border:0.35mm solid #000;padding:0.5mm 2.5mm;font-size:13pt">${entrada ? 0 : 1}</b></div><b>Nº ${numero}<br>SÉRIE: ${nota.serie}<br>FOLHA: 1 de 1</b></td><td style="padding:1mm">${code128c(ch)}</td>`,
     `<td class="cen"><span class="r">Chave de acesso</span><b style="font-size:8.2pt;white-space:nowrap">${ch.replace(/(\d{4})/g, "$1 ").trim()}</b></td>`,
     `<td class="cen" style="vertical-align:middle">Consulta de autenticidade no portal nacional da NF-e<br>www.nfe.fazenda.gov.br/portal ou no site da Sefaz Autorizadora</td>`])}
  ${T([59, 41], [c("Natureza da operação", esc(d.natureza)) + c("Protocolo de autorização de uso", esc(nota.protocolo ? `${nota.protocolo} - ${dt(nota.dh_emissao)} ${hr(nota.dh_emissao)}` : ""), "", "cen")])}
  ${T([33, 34, 33], [c("Inscrição estadual", esc(emp.ie)) + c("Inscrição estadual do subst. trib.", "") + c("CNPJ", doc(emp.cnpj))])}
  <div class="tit">Destinatário / remetente</div>
  ${T([52, 26, 22], [c("Nome / razão social", esc(nomeDest)) + c("CNPJ / CPF", doc(cli.documento)) + c("Data da emissão", dt(nota.dh_emissao), "", "cen")])}
  ${T([44, 24, 10, 22], [c("Endereço", end(cli)) + c("Bairro / distrito", esc(cli.bairro)) + c("CEP", cep(cli.cep)) + c("Data da saída/entrada", dt(d.dh_saida || nota.dh_emissao), "", "cen")])}
  ${T([36, 20, 6, 16, 22], [c("Município", esc(cli.municipio)) + c("Fone / fax", fone(cli.telefone)) + c("UF", esc(cli.uf)) + c("Inscrição estadual", esc(cli.ie)) + c("Hora da saída/entrada", hr(d.dh_saida || nota.dh_emissao), "", "cen")])}
  <div class="tit">Cálculo do imposto</div>
  ${T([20, 20, 20, 20, 20], [c("Base de cálculo do ICMS", "0,00", "", "dir") + c("Valor do ICMS", "0,00", "", "dir") + c("Base de cálc. ICMS S.T.", "0,00", "", "dir") + c("Valor do ICMS subst.", "0,00", "", "dir") + c("Valor total dos produtos", n2(vProd), "", "dir"),
     c("Valor do frete", n2(vFrete), "", "dir") + c("Valor do seguro", "0,00", "", "dir") + c("Desconto", n2(vDesc), "", "dir") + c("Outras despesas", "0,00", "", "dir") + c("Valor total da nota", `<b>${n2(nota.total)}</b>`, "", "dir")])}
  <div class="tit">Transportador / volumes transportados</div>
  ${T([34, 22, 12, 10, 6, 16], [c("Nome / razão social", esc(tr.nome)) + c("Frete por conta", MODFRETE[tr.modalidade ?? 9] || "") + c("Código ANTT", "") + c("Placa do veículo", "") + c("UF", esc(tr.uf)) + c("CNPJ / CPF", doc(tr.documento))])}
  <div class="prod"><div class="tit">Dados do produto / serviço</div><div class="caixa">
  <table class="it"><colgroup><col style="width:8%"><col style="width:30%"><col style="width:8%"><col style="width:5%"><col style="width:5%"><col style="width:4%"><col style="width:7%"><col style="width:8%"><col style="width:9%"><col style="width:4%"><col style="width:4%"><col style="width:4%"><col style="width:4%"></colgroup>
  <tr><th>Código produto</th><th>Descrição do produto / serviço</th><th>NCM/SH</th><th>CSOSN</th><th>CFOP</th><th>UN</th><th>Quant.</th><th>Valor unit.</th><th>Valor total</th><th>B.Cálc ICMS</th><th>Valor ICMS</th><th>Alíq. ICMS</th><th>Alíq. IPI</th></tr>
  ${itens.map(i => `<tr><td>${esc(i.codigo)}</td><td style="white-space:normal">${esc(i.descricao)}</td><td>${esc(i.ncm)}</td><td>${esc(i.csosn || "102")}</td><td>${cfop(i)}</td><td>${esc(i.unidade || "UN")}</td><td class="n">${n4(i.quantidade)}</td><td class="n">${n4(i.preco)}</td><td class="n">${n2((+i.quantidade) * (+i.preco))}</td><td class="n">0,00</td><td class="n">0,00</td><td class="n">0,00</td><td class="n">0,00</td></tr>`).join("")}
  </table><div class="resto"><i style="width:8%"></i><i style="width:30%"></i><i style="width:8%"></i><i style="width:5%"></i><i style="width:5%"></i><i style="width:4%"></i><i style="width:7%"></i><i style="width:8%"></i><i style="width:9%"></i><i style="width:4%"></i><i style="width:4%"></i><i style="width:4%"></i><i style="width:4%"></i></div></div></div>
  <div class="tit">Dados adicionais</div>
  ${T([65, 35], [`<td style="height:32mm;white-space:normal;font-size:8.5pt"><span class="r">Informações complementares</span>${esc(info)}</td><td><span class="r">Reservado ao fisco</span></td>`])}
  <p style="font-size:5.5pt;margin:1mm 0 0">Impresso por NFE Pro Web · ${new Date().toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" })}</p>
  </div></body></html>`;
}
