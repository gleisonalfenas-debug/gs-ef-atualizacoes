Set sh = CreateObject("WScript.Shell")
Set fs = CreateObject("Scripting.FileSystemObject")
pasta = fs.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = pasta

' 1) Se o NFE Pro Web ja estiver rodando (ex.: navegador fechado ha pouco), so abre o navegador.
On Error Resume Next
Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
http.setTimeouts 1000, 1000, 1500, 1500
http.Open "GET", "http://127.0.0.1:8787/__vivo", False
http.Send
rodando = (Err.Number = 0 And http.Status = 204)
Err.Clear
On Error GoTo 0
If rodando Then
  sh.Run "http://localhost:8787"
  WScript.Quit
End If

If sh.Run("cmd /c where node", 0, True) <> 0 Then
  MsgBox "Instale o Node.js LTS (https://nodejs.org) e abra de novo.", 48, "NFE Pro Web"
  WScript.Quit
End If

' 2) Abre sem a janela preta. O registro vai para a pasta temporaria (nunca fica preso a outro processo).
logArq = sh.ExpandEnvironmentStrings("%TEMP%") & "\nfepro_web_log.txt"
sh.Run "cmd /c node --experimental-sqlite --no-warnings ferramentas\iniciar.mjs > """ & logArq & """ 2>&1", 0, False
