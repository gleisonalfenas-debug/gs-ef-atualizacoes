// Atualização automática do NFE Pro Web instalado no PC (igual à do NFE Pro Windows):
// lê o manifesto no GitHub, confere a assinatura do servidor nfspro.com.br, baixa o pacote, confere o SHA-256
// e troca os arquivos do sistema. O banco (nfepro_teste.db) e os backups NUNCA são tocados.
import fs from "node:fs"; import path from "node:path"; import zlib from "node:zlib"; import crypto from "node:crypto"; import { fileURLToPath } from "node:url";
export const RAIZ = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const CHAVE = "yAt22nBvZdzWwy7S2m5jk8x1Om6cDHKQTkJrkeNde3A";   // chave pública do servidor nfspro.com.br
const URL_PADRAO = "https://github.com/gleisonalfenas-debug/gs-ef-atualizacoes/raw/main/web/manifesto_web.json";
const PROTEGIDOS = /^(nfepro_teste\.db(-journal|-wal|-shm)?|backups\/.*|update_url\.txt)$/i;
const b64url = s => Buffer.from(s.replace(/-/g, "+").replace(/_/g, "/"), "base64");
const versao = () => { try { return fs.readFileSync(path.join(RAIZ, "versao.txt"), "utf8").trim(); } catch { return "0.0.0"; } };
const maior = (a, b) => { const x = a.split(".").map(Number), y = b.split(".").map(Number); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); return false; };
const canon = o => JSON.stringify(Object.fromEntries(Object.keys(o).sort().map(k => [k, o[k]])));

function lerZip(buf) {   // ZIP simples (stored/deflate), sem bibliotecas
  let eocd = buf.length - 22; while (eocd >= 0 && buf.readUInt32LE(eocd) !== 0x06054b50) eocd--;
  if (eocd < 0) throw new Error("Pacote ZIP inválido.");
  const n = buf.readUInt16LE(eocd + 10); let p = buf.readUInt32LE(eocd + 16); const arquivos = [];
  for (let i = 0; i < n; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error("Pacote ZIP corrompido.");
    const metodo = buf.readUInt16LE(p + 10), tam = buf.readUInt32LE(p + 20), ln = buf.readUInt16LE(p + 28), le = buf.readUInt16LE(p + 30), lc = buf.readUInt16LE(p + 32), off = buf.readUInt32LE(p + 42);
    const nome = buf.toString("utf8", p + 46, p + 46 + ln); p += 46 + ln + le + lc;
    if (nome.endsWith("/")) continue;
    const ini = off + 30 + buf.readUInt16LE(off + 26) + buf.readUInt16LE(off + 28), dados = buf.subarray(ini, ini + buf.readUInt32LE(off + 18));
    arquivos.push({ nome, conteudo: metodo === 0 ? dados : metodo === 8 ? zlib.inflateRawSync(dados) : (() => { throw new Error("Compressão não suportada."); })(), tam });
  }
  return arquivos;
}

export async function atualizar(log = console.log) {
  let url = URL_PADRAO; try { url = fs.readFileSync(path.join(RAIZ, "update_url.txt"), "utf8").trim() || URL_PADRAO; } catch { /* padrão */ }
  const atual = versao();
  const r = await fetch(url, { signal: AbortSignal.timeout(15000) }); if (r.status === 404) return { atualizado: false, versao: atual }; if (!r.ok) throw new Error("manifesto indisponível (" + r.status + ")");
  const m = await r.json(), pl = m.payload || {};
  const chave = await crypto.webcrypto.subtle.importKey("raw", b64url(process.env.NFEPRO_CHAVE_TESTE || CHAVE), { name: "Ed25519" }, false, ["verify"]);
  if (!(await crypto.webcrypto.subtle.verify({ name: "Ed25519" }, chave, b64url(m.signature || ""), Buffer.from(canon(pl))))) throw new Error("assinatura do manifesto inválida");
  if (pl.product !== "GLEISON-EMISSOR" || !/^\d+\.\d+\.\d+$/.test(pl.version || "") || !String(pl.url || "").startsWith("https://github.com/")) throw new Error("manifesto inválido");
  if (!maior(pl.version, atual)) return { atualizado: false, versao: atual };
  log(`  Baixando a versão ${pl.version} (você está na ${atual})...`);
  const z = await fetch(pl.url, { signal: AbortSignal.timeout(120000) }); if (!z.ok) throw new Error("download falhou (" + z.status + ")");
  const buf = Buffer.from(await z.arrayBuffer());
  if (crypto.createHash("sha256").update(buf).digest("hex") !== pl.sha256) throw new Error("o arquivo baixado não confere (SHA-256)");
  const arquivos = lerZip(buf).map(a => ({ ...a, nome: a.nome.replace(/\\/g, "/").replace(/^NFE_Pro_Web\//, "") }));
  if (!arquivos.some(a => a.nome === "src/worker.js")) throw new Error("pacote sem os arquivos do sistema");
  const db = path.join(RAIZ, "nfepro_teste.db");                      // cópia de segurança antes de trocar
  if (fs.existsSync(db)) { fs.mkdirSync(path.join(RAIZ, "backups"), { recursive: true }); fs.copyFileSync(db, path.join(RAIZ, "backups", `antes_da_${pl.version}_${Date.now()}.db`)); }
  for (const a of arquivos) {
    const destino = path.resolve(RAIZ, a.nome);
    if (!destino.startsWith(RAIZ + path.sep) || PROTEGIDOS.test(a.nome)) continue;   // nada fora da pasta, banco intocado
    fs.mkdirSync(path.dirname(destino), { recursive: true }); fs.writeFileSync(destino + ".novo", a.conteudo); fs.renameSync(destino + ".novo", destino);
  }
  fs.writeFileSync(path.join(RAIZ, "versao.txt"), pl.version + "\n");
  return { atualizado: true, versao: pl.version, anterior: atual };
}
