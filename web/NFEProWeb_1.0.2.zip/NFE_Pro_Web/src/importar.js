// Importação do backup do NFE Pro Windows pela tela (Empresa → Importar backup).
// O navegador abre o gleison_fiscal.db (sql.js) e manda os dados em partes; aqui eles são gravados na empresa da conta.
import { tag as tagX, bloco, dig } from "./nfe.js";
const tag = (x, n) => { const v = tagX(x, n); return v === null ? null : v.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&amp;/g, "&"); };
const s = (v, max = 200) => String(v ?? "").slice(0, max);
export function dadosDoXml(x) {
  const dest = bloco(x, "dest") || "", ed = bloco(dest, "enderDest") || "";
  const itens = [...String(x).matchAll(/<det\s[^>]*>[\s\S]*?<\/det>/g)].map(m => m[0]).map(d => ({ codigo: tag(d, "cProd"), descricao: tag(d, "xProd"), ncm: tag(d, "NCM"), cfop: tag(d, "CFOP"),
    unidade: tag(d, "uCom"), quantidade: tag(d, "qCom"), preco: tag(d, "vUnCom"), desconto: tag(bloco(d, "prod"), "vDesc") || "0", frete: tag(bloco(d, "prod"), "vFrete") || "0", csosn: tag(d, "CSOSN") || "" }));
  return { natureza: tag(x, "natOp"), info: (tag(x, "infCpl") || "").replace(/^DOCUMENTO EMITIDO POR M\w+ OPTANTE PELO SIMPLES NACIONAL\. NAO GERA DIREITO A CREDITO FISCAL DE IPI\.\s*/, ""), itens,
    cliente: { nome: tag(dest, "xNome"), documento: tag(dest, "CNPJ") || tag(dest, "CPF"), ie: tag(dest, "IE") || "", logradouro: tag(ed, "xLgr"), numero: tag(ed, "nro"), complemento: tag(ed, "xCpl") || "",
      bairro: tag(ed, "xBairro"), municipio: tag(ed, "xMun"), uf: tag(ed, "UF"), cep: tag(ed, "CEP") || "", codigo_municipio: tag(ed, "cMun") } };
}
export async function importar(env, emp, corpo) {
  const agora = new Date().toISOString(), R = { clientes: 0, produtos: 0, notas: 0, eventos: 0, ignoradas: 0 };
  if (corpo.parte === "cadastro") {
    const c = corpo.empresa || {}, cnpj = dig(c.cnpj);
    if (cnpj.length !== 14) throw new Error("O backup não tem empresa com CNPJ.");
    if (emp.cnpj && dig(emp.cnpj) !== cnpj) throw new Error(`Este backup é de outro CNPJ (${cnpj}). A empresa desta conta é ${emp.cnpj}.`);
    const sq = corpo.seq || {};
    await env.DB.prepare(`UPDATE empresas SET cnpj=?, ie=?, razao_social=?, fantasia=?, logradouro=?, numero=?, complemento=?, bairro=?, codigo_municipio=?, municipio=?, uf=?, cep=?, telefone=?,
      ambiente=?, serie=?, proximo_numero=MAX(proximo_numero, ?), proximo_homolog=MAX(proximo_homolog, ?), atualizado_em=? WHERE id=?`).bind(cnpj, dig(c.ie), s(c.legal_name, 60), s(c.trade_name, 60),
      s(c.logradouro, 60), s(c.numero, 60), s(c.complemento, 60), s(c.bairro, 60), dig(c.codigo_municipio).slice(0, 7), s(c.municipio, 60), s(c.uf || "MG", 2), dig(c.cep).slice(0, 8), s(c.telefone, 20),
      c.ambiente_nfe === "1" ? "1" : "2", +c.serie_nfe || 1, Math.max(1, +sq.producao || 1), Math.max(1, +sq.homologacao || 1), agora, emp.id).run();
    for (const r of corpo.clientes || []) {
      const doc = dig(r.document); if (!r.name) continue;
      if (await env.DB.prepare("SELECT 1 FROM clientes WHERE empresa_id=? AND nome=? AND COALESCE(documento,'')=?").bind(emp.id, s(r.name, 60), doc).first()) continue;
      await env.DB.prepare("INSERT INTO clientes (empresa_id, nome, documento, ie, indicador_ie, email, telefone, cep, logradouro, numero, complemento, bairro, codigo_municipio, municipio, uf) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
        .bind(emp.id, s(r.name, 60), doc, dig(r.ie), s(r.indicador_ie || (r.ie ? "1" : "9"), 1), s(r.email, 60), s(r.telefone, 20), dig(r.cep).slice(0, 8), s(r.logradouro, 60), s(r.numero, 60), s(r.complemento, 60), s(r.bairro, 60), dig(r.codigo_municipio).slice(0, 7), s(r.municipio, 60), s(r.uf || "MG", 2)).run(); R.clientes++;
    }
    for (const r of corpo.produtos || []) {
      const cod = s(r.code || r.id, 60); if (!r.description) continue;
      if (await env.DB.prepare("SELECT 1 FROM produtos WHERE empresa_id=? AND codigo=?").bind(emp.id, cod).first()) continue;
      await env.DB.prepare("INSERT INTO produtos (empresa_id, codigo, descricao, ncm, cest, ean, unidade, preco, origem, csosn, pis_cst) VALUES (?,?,?,?,?,?,?,?,?,?,?)")
        .bind(emp.id, cod, s(r.description, 120), dig(r.ncm).slice(0, 8), dig(r.cest).slice(0, 7), dig(r.ean).slice(0, 14), s(r.unit || "UN", 6), String(+r.price || 0), s(r.origin ?? "0", 1) || "0", "102", "99").run(); R.produtos++;
    }
    return R;
  }
  if (corpo.parte === "notas") {
    const cnpj = dig(emp.cnpj);
    for (const r of corpo.notas || []) {
      const ch = dig(r.chave); if (ch.length !== 44 || ch.slice(6, 20) !== cnpj) { R.ignoradas++; continue; }   // só notas desta empresa
      if (await env.DB.prepare("SELECT 1 FROM notas WHERE chave=?").bind(ch).first()) continue;
      const xa = r.xml_assinado || null, xp = r.xml_autorizado || null, x = xp || xa;
      await env.DB.prepare("INSERT INTO notas (empresa_id, ambiente, serie, numero, chave, situacao, cstat, motivo, protocolo, recibo, dh_emissao, total, destinatario, dados, xml_assinado, xml_autorizado, criada_em, atualizada_em) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
        .bind(emp.id, r.ambiente === "1" ? "1" : "2", +r.serie || 1, +r.numero || 0, ch, s(r.situacao, 20), s(r.cstat, 5), s(r.motivo, 300), s(r.protocolo, 20), s(r.recibo, 20), s(r.dh_emissao, 30), s(r.total, 20), s(r.destinatario, 60),
          x ? JSON.stringify(dadosDoXml(x)) : "{}", xa, xp, s(r.criada_em || agora, 30), s(r.atualizada_em || agora, 30)).run(); R.notas++;
    }
    for (const e of corpo.eventos || []) {
      const ch = dig(e.chave); if (ch.slice(6, 20) !== cnpj) continue;
      const res = await env.DB.prepare("INSERT OR IGNORE INTO eventos (chave, tipo, seq, cstat, motivo, protocolo, texto, xml, criado_em) VALUES (?,?,?,?,?,?,?,?,?)")
        .bind(ch, s(e.tipo, 20), +e.seq || 1, s(e.cstat, 5), s(e.motivo, 300), s(e.protocolo, 20), s(e.texto, 1000), e.xml || null, s(e.criado_em || agora, 30)).run(); R.eventos += res?.meta?.changes ?? 1;
    }
    return R;
  }
  throw new Error("Parte inválida.");
}
