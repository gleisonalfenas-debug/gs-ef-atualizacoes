// DANFE em HTML pronto para imprimir / salvar em PDF pelo navegador (Ctrl+P). Código de barras Code 128-C em SVG.
const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const doc = d => (d = String(d || "").replace(/\D/g, "")).length === 14 ? d.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, "$1.$2.$3/$4-$5") : d.length === 11 ? d.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4") : d;
const dt = s => s ? `${s.slice(8, 10)}/${s.slice(5, 7)}/${s.slice(0, 4)} ${s.slice(11, 16)}` : "";
const brl = v => (+v || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const P = ["212222","222122","222221","121223","121322","131222","122213","122312","132212","221213","221312","231212","112232","122132","122231","113222","123122","123221","223211","221132","221231","213212","223112","312131","311222","321122","321221","312212","322112","322211","212123","212321","232121","111323","131123","131321","112313","132113","132311","211313","231113","231311","112133","112331","132131","113123","113321","133121","313121","211331","231131","213113","213311","213131","311123","311321","331121","312113","312311","332111","314111","221411","431111","111224","111422","121124","121421","141122","141221","112214","112412","122114","122411","142112","142211","241211","221114","413111","241112","134111","111242","121142","121241","114212","124112","124211","411212","421112","421211","212141","214121","412121","111143","111341","131141","114113","114311","411113","411311","113141","114131","311141","411131","211412","211214","211232","2331112"];
export function code128c(d) {
  const cods = [105]; for (let i = 0; i < d.length; i += 2) cods.push(+d.slice(i, i + 2));
  cods.push(cods.reduce((s, c, i) => s + c * (i || 1), 0) % 103); cods.push(106);
  let x = 10, barras = ""; for (const c of cods) [...P[c]].forEach((w, i) => { if (i % 2 === 0) barras += `<rect x="${x}" y="0" width="${w}" height="50"/>`; x += +w; });
  return `<svg viewBox="0 0 ${x + 10} 50" preserveAspectRatio="none" style="width:100%;height:46px">${barras}</svg>`;
}
export function danfeHTML(nota, emp) {
  const d = JSON.parse(nota.dados || "{}"), cli = d.cliente || {}, itens = d.itens || [], ch = nota.chave;
  const marca = nota.situacao === "CANCELADA" ? "NF-e CANCELADA" : nota.ambiente === "2" ? "HOMOLOGAÇÃO — SEM VALOR FISCAL" : nota.situacao !== "AUTORIZADA" ? "NÃO AUTORIZADA — SEM VALOR FISCAL" : "";
  const prod = itens.reduce((s, i) => s + (+i.quantidade || 0) * (+i.preco || 0), 0);
  const end = r => `${esc(r.logradouro)}, ${esc(r.numero || "SN")}${r.complemento ? " - " + esc(r.complemento) : ""} - ${esc(r.bairro)} - ${esc(r.municipio)}/${esc(r.uf)}`;
  const cfop = (it) => { const c = String(it.cfop || "5102"); return (cli.uf === "MG" ? (c[0] <= "3" ? "1" : "5") : (c[0] <= "3" ? "2" : "6")) + c.slice(1); };
  return `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><title>DANFE ${nota.numero}</title><style>
  @page{size:A4;margin:8mm}body{font:10px Arial,sans-serif;color:#000;margin:0;padding:10px}.b{border:1px solid #000;padding:3px 5px;margin:-1px 0 0}
  .g{display:grid;gap:0}.g>div{border:1px solid #000;margin:-1px 0 0 -1px;padding:2px 5px}small{display:block;font-size:7.5px;text-transform:uppercase}
  table{width:100%;border-collapse:collapse;margin-top:-1px}th,td{border:1px solid #000;padding:2px 4px;font-size:9px}th{font-size:7.5px}td.r{text-align:right}
  .marca{position:fixed;top:40%;left:0;right:0;text-align:center;font-size:42px;color:#c62828;opacity:.25;transform:rotate(-20deg);font-weight:700;pointer-events:none}
  .acoes{margin-bottom:8px}@media print{.acoes{display:none}}h1{font-size:14px;margin:0}
  </style></head><body>${marca ? `<div class="marca">${marca}</div>` : ""}<div class="acoes"><button onclick="print()">Imprimir / Salvar em PDF</button></div>
  <div class="g" style="grid-template-columns:2fr 1fr 2fr"><div><h1>${esc(emp.razao_social)}</h1>${end(emp)}<br>CEP ${esc(emp.cep)} · Fone ${esc(emp.telefone)}</div>
  <div style="text-align:center"><b style="font-size:14px">DANFE</b><br>Documento Auxiliar da Nota Fiscal Eletrônica<br>1 - SAÍDA<br><b>Nº ${String(nota.numero).padStart(9, "0").replace(/(\d{3})(\d{3})(\d{3})/, "$1.$2.$3")}</b><br>SÉRIE ${nota.serie}</div>
  <div>${code128c(ch)}<small>Chave de acesso</small><b>${ch.replace(/(\d{4})/g, "$1 ")}</b><br>Consulta em www.nfe.fazenda.gov.br/portal</div></div>
  <div class="g" style="grid-template-columns:2fr 1fr"><div><small>Natureza da operação</small>${esc(d.natureza)}</div><div><small>Protocolo de autorização</small>${esc(nota.protocolo || "-")}</div></div>
  <div class="g" style="grid-template-columns:1fr 1fr 1fr"><div><small>Inscrição estadual</small>${esc(emp.ie)}</div><div><small>CNPJ</small>${esc(doc(emp.cnpj))}</div><div><small>Emissão</small>${esc(dt(nota.dh_emissao))}</div></div>
  <div class="b"><b>DESTINATÁRIO</b></div><div class="g" style="grid-template-columns:2fr 1fr"><div><small>Nome / razão social</small>${esc(cli.nome)}</div><div><small>CPF/CNPJ</small>${esc(doc(cli.documento))}</div></div>
  <div class="g" style="grid-template-columns:3fr 1fr"><div><small>Endereço</small>${end(cli)}</div><div><small>IE</small>${esc(cli.ie || "")}</div></div>
  <div class="b"><b>PRODUTOS / SERVIÇOS</b></div><table><thead><tr><th>CÓDIGO</th><th>DESCRIÇÃO</th><th>NCM</th><th>CSOSN</th><th>CFOP</th><th>UN</th><th>QTD</th><th>V. UNIT</th><th>V. TOTAL</th></tr></thead><tbody>
  ${itens.map(i => `<tr><td>${esc(i.codigo)}</td><td>${esc(i.descricao)}</td><td>${esc(i.ncm)}</td><td>${esc(i.csosn || "102")}</td><td>${cfop(i)}</td><td>${esc(i.unidade || "UN")}</td><td class="r">${(+i.quantidade).toLocaleString("pt-BR")}</td><td class="r">${brl(i.preco)}</td><td class="r">${brl((+i.quantidade) * (+i.preco))}</td></tr>`).join("")}</tbody></table>
  <div class="g" style="grid-template-columns:repeat(4,1fr)"><div><small>Valor dos produtos</small>${brl(prod)}</div><div><small>Frete</small>${brl(itens.reduce((s, i) => s + (+i.frete || 0), 0))}</div><div><small>Desconto</small>${brl(itens.reduce((s, i) => s + (+i.desconto || 0), 0))}</div><div><small>Valor total da nota</small><b>${brl(nota.total)}</b></div></div>
  <div class="b" style="min-height:60px"><small>Informações complementares</small>DOCUMENTO EMITIDO POR MEI OPTANTE PELO SIMPLES NACIONAL. NAO GERA DIREITO A CREDITO FISCAL DE IPI. ${esc(d.info || "")}</div>
  <p style="font-size:8px">Impresso por NFE Pro Web</p></body></html>`;
}
