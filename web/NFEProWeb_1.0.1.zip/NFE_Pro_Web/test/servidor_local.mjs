// NFE Pro Web rodando no seu PC, sem Cloudflare: banco em arquivo (nfepro_teste.db) e SEFAZ SIMULADA
// (as notas saem "autorizadas" de mentira, só para testar as telas). Abra http://localhost:8787
import http from "node:http"; import fs from "node:fs"; import path from "node:path"; import { fileURLToPath } from "node:url";
import { DatabaseSync } from "node:sqlite";
import worker from "../src/worker.js"; import * as N from "../src/nfe.js";
const raiz = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const db = new DatabaseSync(path.join(raiz, "nfepro_teste.db")); db.exec(fs.readFileSync(path.join(raiz, "schema.sql"), "utf8"));
const D1 = { prepare(sql) { let a = []; const st = db.prepare(sql); const o = { bind(...x) { a = x.map(v => (v === undefined ? null : v)); return o; },
  async first() { const r = st.get(...a); return r ? { ...r } : null; }, async all() { return { results: st.all(...a).map(r => ({ ...r })) }; }, async run() { st.run(...a); return {}; } }; return o; } };
let prot = 131260000000000;
const sefaz = { async fetch(url, init) {
  const s = url.split("/").pop(), ok = x => new Response(`<Envelope><Body>${x}</Body></Envelope>`), agora = N.dh(new Date());
  if (s === "NFeAutorizacao4") { const ch = init.body.match(/Id="NFe(\d{44})"/)[1];
    return ok(`<retEnviNFe xmlns="${N.NFE}" versao="4.00"><cStat>104</cStat><xMotivo>Lote processado (SIMULADO)</xMotivo><protNFe versao="4.00"><infProt><tpAmb>2</tpAmb><verAplic>SIMULADO</verAplic><chNFe>${ch}</chNFe><dhRecbto>${agora}</dhRecbto><nProt>${++prot}</nProt><cStat>100</cStat><xMotivo>Autorizado o uso da NF-e (SIMULADO)</xMotivo></infProt></protNFe></retEnviNFe>`); }
  if (s === "NFeStatusServico4") return ok(`<retConsStatServ xmlns="${N.NFE}"><cStat>107</cStat><xMotivo>Servico em Operacao (SIMULADO)</xMotivo></retConsStatServ>`);
  if (s === "NFeConsultaProtocolo4") return ok(`<retConsSitNFe xmlns="${N.NFE}"><cStat>999</cStat><xMotivo>Consulta SIMULADA: sem SEFAZ no teste local</xMotivo></retConsSitNFe>`);
  return ok(`<retEnvEvento xmlns="${N.NFE}"><cStat>128</cStat><xMotivo>ok</xMotivo><retEvento versao="1.00"><infEvento><cStat>135</cStat><xMotivo>Evento registrado e vinculado a NF-e (SIMULADO)</xMotivo><nProt>${++prot}</nProt></infEvento></retEvento></retEnvEvento>`); } };
const tipos = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".png": "image/png", ".svg": "image/svg+xml" };
const env = new Proxy({ DB: D1, CHAVE_MESTRA: "teste-local-no-pc-nao-use-em-producao", ADMIN_EMAIL: process.env.ADMIN_EMAIL || "gleisonalfenas@icloud.com", DIAS_TESTE: "7", SUPORTE: "teste local",
  ASSETS: { fetch: async r => { let p = new URL(r.url).pathname; if (p === "/") p = "/index.html"; const f = path.join(raiz, "public", path.normalize(p).replace(/^([\\/]\.\.)+/, ""));
    return fs.existsSync(f) && f.startsWith(path.join(raiz, "public")) ? new Response(fs.readFileSync(f), { headers: { "content-type": tipos[path.extname(f)] || "application/octet-stream" } }) : new Response("Não encontrado", { status: 404 }); } } },
  { get: (t, k) => (typeof k === "string" && k.startsWith("CERT_") ? sefaz : t[k]) });
http.createServer(async (q, s) => {
  try { const b = []; for await (const c of q) b.push(c);
    const r = await worker.fetch(new Request("http://localhost:8787" + q.url, { method: q.method, headers: q.headers, body: q.method === "GET" || q.method === "HEAD" ? undefined : Buffer.concat(b) }), env);
    const h = {}; r.headers.forEach((v, k) => { h[k] = k === "set-cookie" ? v.replace("; Secure", "") : v; }); s.writeHead(r.status, h); s.end(Buffer.from(await r.arrayBuffer()));
  } catch (e) { s.writeHead(500); s.end(String(e)); }
}).listen(8787, "127.0.0.1", async () => { console.log("\n  NFE Pro Web (TESTE, SEFAZ SIMULADA) rodando em  http://localhost:8787\n  Para parar, feche esta janela.\n");
  if (process.platform === "win32" && !process.env.NFEPRO_SEM_NAVEGADOR) (await import("node:child_process")).spawn("cmd", ["/c", "start", "", "http://localhost:8787"], { detached: true, stdio: "ignore" }).unref(); });
