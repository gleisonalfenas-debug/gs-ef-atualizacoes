// Importação do backup do NFE Pro Windows pela tela (Empresa → Importar backup).
// O navegador abre o gleison_fiscal.db (sql.js) e manda os dados em partes; aqui eles são gravados na empresa da conta.
import { tag as tagX, bloco, dig } from "./nfe.js";
const tag = (x, n) => { const v = tagX(x, n); return v === null ? null : v.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&amp;/g, "&"); };
const s = (v, max = 200) => String(v ?? "").slice(0, max);
export function dadosDoXml(x) {
  const dest = bloco(x, "dest") || "", ed = bloco(dest, "enderDest") || "";
  const itens = [...String(x).matchAll(/<det\s[^>]*>[\s\S]*?<\/det>/g)].map(m => m[0]).map(d => ({ codigo: tag(d, "cProd"), descricao: tag(d, "xProd"), ncm: tag(d, "NCM"), cfop: tag(d, "CFOP"),
    unidade: tag(d, "uCom"), quantidade: tag(d, "qCom"), preco: tag(d, "vUnCom"), desconto: tag(bloco(d, "prod"), "vDesc") || "0", frete: tag(bloco(d, "prod"), "vFrete") || "0", csosn: tag(d, "CSOSN") || "" }));
  return { natureza: tag(x, "natOp"), info: (tag(x, "infCpl") || "").replace(/^DOCUMENTO EMITIDO POR M\w+ OPTANTE PELO SIMPLES NACIONAL\. NAO GERA DIREITO A CREDITO FISCAL DE IPI\.\s*/, ""), itens,
    cliente: { nome: tag(dest, "xNome"), documento: tag(dest, "CNPJ") || tag(dest, "CPF"), ie: tag(dest, "IE") || "", logradouro: tag(ed, "xLgr"), numero: tag(ed, "nro"), complemento: tag(ed, "xCpl") || "",
      bairro: tag(ed, "xBairro"), municipio: tag(ed, "xMun"), uf: tag(ed, "UF"), cep: tag(ed, "CEP") || "", codigo_municipio: tag(ed, "cMun") } };
}
export async function importar(env, emp, corpo) {
  const agora = new Date().toISOString(), R = { clientes: 0, produtos: 0, notas: 0, eventos: 0, ignoradas: 0 };
  if (corpo.parte === "cadastro") {
    const c = corpo.empresa || {}, cnpj = dig(c.cnpj);
    if (cnpj.length !== 14) throw new Error("O backup não tem empresa com CNPJ.");
    if (emp.cnpj && dig(emp.cnpj) !== cnpj) throw new Error(`Este backup é de outro CNPJ (${cnpj}). A empresa desta conta é ${emp.cnpj}.`);
    const sq = corpo.seq || {};
    await env.DB.prepare(`UPDATE empresas SET cnpj=?, ie=?, razao_social=?, fantasia=?, logradouro=?, numero=?, complemento=?, bairro=?, codigo_municipio=?, municipio=?, uf=?, cep=?, telefone=?,
      ambiente=?, serie=?, proximo_numero=MAX(proximo_numero, ?), proximo_homolog=MAX(proximo_homolog, ?), atualizado_em=? WHERE id=?`).bind(cnpj, dig(c.ie), s(c.legal_name, 60), s(c.trade_name, 60),
      s(c.logradouro, 60), s(c.numero, 60), s(c.complemento, 60), s(c.bairro, 60), dig(c.codigo_municipio).slice(0, 7), s(c.municipio, 60), s(c.uf || "MG", 2), dig(c.cep).slice(0, 8), s(c.telefone, 20),
      c.ambiente_nfe === "1" ? "1" : "2", +c.serie_nfe || 1, Math.max(1, +sq.producao || 1), Math.max(1, +sq.homologacao || 1), agora, emp.id).run();
    for (const r of corpo.clientes || []) {
      const doc = dig(r.document); if (!r.name) continue;
      if (await env.DB.prepare("SELECT 1 FROM clientes WHERE empresa_id=? AND nome=? AND COALESCE(documento,'')=?").bind(emp.id, s(r.name, 60), doc).first()) continue;
      await env.DB.prepare("INSERT INTO clientes (empresa_id, nome, documento, ie, indicador_ie, email, telefone, cep, logradouro, numero, complemento, bairro, codigo_municipio, municipio, uf) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
        .bind(emp.id, s(r.name, 60), doc, dig(r.ie), s(r.indicador_ie || (r.ie ? "1" : "9"), 1), s(r.email, 60), s(r.telefone, 20), dig(r.cep).slice(0, 8), s(r.logradouro, 60), s(r.numero, 60), s(r.complemento, 60), s(r.bairro, 60), dig(r.codigo_municipio).slice(0, 7), s(r.municipio, 60), s(r.uf || "MG", 2)).run(); R.clientes++;
    }
    for (const r of corpo.produtos || []) {
      const cod = s(r.code || r.id, 60); if (!r.description) continue;
      if (await env.DB.prepare("SELECT 1 FROM produtos WHERE empresa_id=? AND codigo=?").bind(emp.id, cod).first()) continue;
      await env.DB.prepare("INSERT INTO produtos (empresa_id, codigo, descricao, ncm, cest, ean, unidade, preco, origem, csosn, pis_cst) VALUES (?,?,?,?,?,?,?,?,?,?,?)")
        .bind(emp.id, cod, s(r.description, 120), dig(r.ncm).slice(0, 8), dig(r.cest).slice(0, 7), dig(r.ean).slice(0, 14), s(r.unit || "UN", 6), String(+r.price || 0), s(r.origin ?? "0", 1) || "0", "102", "99").run(); R.produtos++;
    }
    return R;
  }
  if (corpo.parte === "notas") {
    const cnpj = dig(emp.cnpj);
    for (const r of corpo.notas || []) {
      const ch = dig(r.chave); if (ch.length !== 44 || ch.slice(6, 20) !== cnpj) { R.ignoradas++; continue; }   // só notas desta empresa
      if (await env.DB.prepare("SELECT 1 FROM notas WHERE chave=?").bind(ch).first()) continue;
      const xa = r.xml_assinado || null, xp = r.xml_autorizado || null, x = xp || xa;
      await env.DB.prepare("INSERT INTO notas (empresa_id, ambiente, serie, numero, chave, situacao, cstat, motivo, protocolo, recibo, dh_emissao, total, destinatario, dados, xml_assinado, xml_autorizado, criada_em, atualizada_em) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
        .bind(emp.id, r.ambiente === "1" ? "1" : "2", +r.serie || 1, +r.numero || 0, ch, s(r.situacao, 20), s(r.cstat, 5), s(r.motivo, 300), s(r.protocolo, 20), s(r.recibo, 20), s(r.dh_emissao, 30), s(r.total, 20), s(r.destinatario, 60),
          x ? JSON.stringify(dadosDoXml(x)) : "{}", xa, xp, s(r.criada_em || agora, 30), s(r.atualizada_em || agora, 30)).run(); R.notas++;
    }
    for (const e of corpo.eventos || []) {
      const ch = dig(e.chave); if (ch.slice(6, 20) !== cnpj) continue;
      const res = await env.DB.prepare("INSERT OR IGNORE INTO eventos (chave, tipo, seq, cstat, motivo, protocolo, texto, xml, criado_em) VALUES (?,?,?,?,?,?,?,?,?)")
        .bind(ch, s(e.tipo, 20), +e.seq || 1, s(e.cstat, 5), s(e.motivo, 300), s(e.protocolo, 20), s(e.texto, 1000), e.xml || null, s(e.criado_em || agora, 30)).run(); R.eventos += res?.meta?.changes ?? 1;
    }
    return R;
  }
  throw new Error("Parte inválida.");
}

// Importa XML de venda (nfeProc / NFe autorizada) emitida por OUTRO sistema, e cancelamentos (procEventoNFe 110111).
export async function importarXml(env, emp, xmls) {
  const cnpjEmp = dig(emp.cnpj), agora = new Date().toISOString(), R = { notas: 0, ja: 0, canceladas: 0, recusadas: [] };
  if (cnpjEmp.length !== 14) throw new Error("Cadastre o CNPJ da empresa antes de importar XML.");
  for (const [nome, x0] of xmls) {
    const x = String(x0 || "").replace(/^\uFEFF/, "");
    try {
      if (/<procEventoNFe[\s>]/.test(x) || (/<evento[\s>]/.test(x) && !/<NFe[\s>]/.test(x))) {      // evento de cancelamento
        const ch = tag(x, "chNFe"), tp = tag(x, "tpEvento"), st = tag(bloco(x, "retEvento") || "", "cStat");
        if (tp !== "110111" || !["135", "155"].includes(st || "")) throw new Error("evento não é cancelamento homologado");
        const n = await env.DB.prepare("SELECT situacao FROM notas WHERE chave=? AND empresa_id=?").bind(ch, emp.id).first();
        if (!n) throw new Error("cancelamento de uma nota que ainda não foi importada (importe o XML da nota antes)");
        if (n.situacao !== "CANCELADA") { await env.DB.prepare("UPDATE notas SET situacao='CANCELADA', cstat=?, motivo=?, atualizada_em=? WHERE chave=?").bind(st, tag(bloco(x, "retEvento"), "xMotivo"), agora, ch).run(); R.canceladas++; }
        await env.DB.prepare("INSERT OR IGNORE INTO eventos (chave, tipo, seq, cstat, motivo, protocolo, texto, xml, criado_em) VALUES (?,?,?,?,?,?,?,?,?)").bind(ch, "cancelamento", 1, st, tag(bloco(x, "retEvento"), "xMotivo"), tag(bloco(x, "retEvento"), "nProt"), tag(x, "xJust"), x, agora).run();
        continue;
      }
      const nfe = bloco(x, "NFe"); if (!nfe) throw new Error("não é um XML de NF-e");
      const id = (nfe.match(/<infNFe[^>]*\sId="NFe(\d{44})"/) || [])[1]; if (!id) throw new Error("XML sem chave de acesso");
      let soma = 0, p = 2; for (let i = 42; i >= 0; i--) { soma += +id[i] * p; p = p === 9 ? 2 : p + 1; } const dv = soma % 11 < 2 ? 0 : 11 - (soma % 11);
      if (+id[43] !== dv) throw new Error("chave de acesso com dígito inválido");
      if (tag(nfe, "mod") !== "55") throw new Error("não é NF-e modelo 55");
      if (dig(tag(bloco(nfe, "emit"), "CNPJ")) !== cnpjEmp) throw new Error("nota emitida por outro CNPJ (aqui só entram as suas vendas)");
      if (!/<Signature[\s>]/.test(nfe)) throw new Error("XML sem assinatura digital");
      if (await env.DB.prepare("SELECT 1 FROM notas WHERE chave=?").bind(id).first()) { R.ja++; continue; }
      const prot = bloco(x, "protNFe"), cst = prot ? tag(prot, "cStat") : null;
      const situacao = ["100", "150"].includes(cst) ? "AUTORIZADA" : ["110", "301", "302", "303"].includes(cst) ? "DENEGADA" : "INDETERMINADA";
      const amb = tag(bloco(nfe, "ide"), "tpAmb") === "1" ? "1" : "2", serie = +tag(bloco(nfe, "ide"), "serie") || 0, num = +tag(bloco(nfe, "ide"), "nNF") || 0;
      await env.DB.prepare("INSERT INTO notas (empresa_id, ambiente, serie, numero, chave, situacao, cstat, motivo, protocolo, dh_emissao, total, destinatario, dados, xml_assinado, xml_autorizado, criada_em, atualizada_em) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
        .bind(emp.id, amb, serie, num, id, situacao, cst, prot ? tag(prot, "xMotivo") : "XML importado sem protocolo", prot ? tag(prot, "nProt") : null, tag(bloco(nfe, "ide"), "dhEmi"),
          tag(bloco(nfe, "ICMSTot"), "vNF"), tag(bloco(nfe, "dest"), "xNome") || "", JSON.stringify(dadosDoXml(nfe)), nfe, prot ? x : null, agora, agora).run();
      if (serie === +emp.serie && num) await env.DB.prepare(`UPDATE empresas SET ${amb === "1" ? "proximo_numero" : "proximo_homolog"}=MAX(${amb === "1" ? "proximo_numero" : "proximo_homolog"}, ?) WHERE id=?`).bind(num + 1, emp.id).run();
      R.notas++;
    } catch (e) { R.recusadas.push(`${nome}: ${e.message}`); }
  }
  return R;
}
