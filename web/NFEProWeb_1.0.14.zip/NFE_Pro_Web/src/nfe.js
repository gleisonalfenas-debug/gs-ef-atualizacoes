// NFE Pro Web — núcleo fiscal da NF-e 4.00 (MEI CRT 4 e Simples Nacional CRT 1, SEFAZ/MG) em JavaScript puro (Cloudflare Workers).
// Porte do emissao_nfe.py do programa do Windows. O XML é gerado já na forma canônica (C14N 1.0), assim o digest
// e a assinatura RSA-SHA1 batem sem precisar de biblioteca de XML.

export const NFE = "http://www.portalfiscal.inf.br/nfe";
const DS = "http://www.w3.org/2000/09/xmldsig#";
const WSDL = "http://www.portalfiscal.inf.br/nfe/wsdl/";
export const BASE_URL = { "1": "https://nfe.fazenda.mg.gov.br/nfe2/services/", "2": "https://hnfe.fazenda.mg.gov.br/nfe2/services/" };
export const SERVICOS = {
  autorizacao: ["NFeAutorizacao4", "nfeAutorizacaoLote"], retautorizacao: ["NFeRetAutorizacao4", "nfeRetAutorizacaoLote"],
  consulta: ["NFeConsultaProtocolo4", "nfeConsultaNF"], status: ["NFeStatusServico4", "nfeStatusServicoNF"],
  evento: ["NFeRecepcaoEvento4", "nfeRecepcaoEvento"],
};
export const XNOME_HOMOLOG = "NF-E EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL";
export const COD_UF = { RO: "11", AC: "12", AM: "13", RR: "14", PA: "15", AP: "16", TO: "17", MA: "21", PI: "22", CE: "23", RN: "24", PB: "25", PE: "26", AL: "27", SE: "28", BA: "29", MG: "31", ES: "32", RJ: "33", SP: "35", PR: "41", SC: "42", RS: "43", MS: "50", MT: "51", GO: "52", DF: "53" };
export const FORMAS_PAGAMENTO = { "01": "Dinheiro", "02": "Cheque", "03": "Cartão de crédito", "04": "Cartão de débito", "05": "Crédito loja", "10": "Vale alimentação", "11": "Vale refeição", "12": "Vale presente", "13": "Vale combustível", "15": "Boleto bancário", "16": "Depósito bancário", "17": "PIX dinâmico", "18": "Transferência bancária / carteira digital", "19": "Programa de fidelidade", "20": "PIX estático", "21": "Crédito em loja", "90": "Sem pagamento", "99": "Outros" };
export const MODALIDADES_FRETE = { "0": "0 - Por conta do Remetente (CIF)", "1": "1 - Por conta do Destinatário (FOB)", "2": "2 - Por conta de Terceiros", "3": "3 - Próprio por conta do Remetente", "4": "4 - Próprio por conta do Destinatário", "9": "9 - Sem Ocorrência de Transporte" };
const TEXTO_CCE = "A Carta de Correcao e disciplinada pelo paragrafo 1o-A do art. 7o do Convenio S/N, de 15 de dezembro de 1970 e pode ser utilizada para regularizacao de erro ocorrido na emissao de documento fiscal, desde que o erro nao esteja relacionado com: I - as variaveis que determinam o valor do imposto tais como: base de calculo, aliquota, diferenca de preco, quantidade, valor da operacao ou da prestacao; II - a correcao de dados cadastrais que implique mudanca do remetente ou do destinatario; III - a data de emissao ou de saida.";

export class ErroEmissao extends Error {}

// ---------------------------------------------------------------- XML canônico
const escT = s => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\r/g, "&#xD;");
const escA = s => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/"/g, "&quot;").replace(/\t/g, "&#x9;").replace(/\n/g, "&#xA;").replace(/\r/g, "&#xD;");
export function E(nome, attrs, ...filhos) { return { nome, attrs: attrs || {}, filhos: filhos.flat().filter(f => f !== null && f !== undefined && f !== false) }; }
export function xml(no, ns) {
  if (typeof no === "string" || typeof no === "number") return escT(no);
  const a = { ...no.attrs }; if (ns) a.xmlns = ns;
  const chaves = Object.keys(a).sort((x, y) => (x === "xmlns" ? -1 : y === "xmlns" ? 1 : x < y ? -1 : x > y ? 1 : 0));
  return `<${no.nome}${chaves.map(k => ` ${k}="${escA(a[k])}"`).join("")}>${no.filhos.map(f => xml(f)).join("")}</${no.nome}>`;
}
const el = (nome, valor) => (valor === null || valor === undefined ? null : E(nome, null, String(valor)));

// ---------------------------------------------------------------- utilidades
export const dig = v => String(v ?? "").replace(/\D/g, "");
export function txt(v, max, min = 1, campo = "campo") {
  let s = String(v ?? "").normalize("NFC").replace(/[\x00-\x1f\x7f]/g, " ").replace(/\s+/g, " ").trim().slice(0, max).trim();
  if (s.length < min) throw new ErroEmissao(`${campo}: informe ao menos ${min} caractere(s).`);
  return s;
}
// decimais exatos com BigInt (escala 10^10)
const ESC = 10n ** 10n;
export function dec(v) {
  let s = String(v ?? "0").trim().replace(",", "."); if (!s) s = "0";
  if (!/^-?\d*(\.\d*)?$/.test(s)) throw new ErroEmissao(`Número inválido: ${v}`);
  const neg = s.startsWith("-"); if (neg) s = s.slice(1);
  let [i, f = ""] = s.split("."); f = (f + "0000000000").slice(0, 10);
  const r = BigInt(i || "0") * ESC + BigInt(f); return neg ? -r : r;
}
function arred(v, casas) { const q = 10n ** BigInt(10 - casas); const r = (v >= 0n ? v + q / 2n : v - q / 2n) / q; return r * q; }
export function fmt(v, casas = 2) {
  const x = arred(typeof v === "bigint" ? v : dec(v), casas); const neg = x < 0n; const a = neg ? -x : x;
  const i = a / ESC, f = String(a % ESC).padStart(10, "0").slice(0, casas);
  return (neg ? "-" : "") + i + (casas ? "." + f : "");
}
function fmtUnit(v) { const d = typeof v === "bigint" ? v : dec(v); return arred(d, 4) === d ? fmt(d, 4) : fmt(d, 10); }
const mul = (a, b) => (a * b) / ESC;
export function dv11(base) { let s = 0, p = 2; for (let i = base.length - 1; i >= 0; i--) { s += +base[i] * p; p = p === 9 ? 2 : p + 1; } const r = s % 11; return r < 2 ? 0 : 11 - r; }
export function agoraMG(margemMin = 1) { return new Date(Date.now() - margemMin * 60000); }
export function dh(d) { const t = new Date(d.getTime() - 3 * 3600000); return t.toISOString().slice(0, 19) + "-03:00"; }
function aamm(d) { return dh(d).slice(2, 4) + dh(d).slice(5, 7); }
export function gtinValido(c) { c = dig(c); if (![8, 12, 13, 14].includes(c.length)) return false; let s = 0; [...c.slice(0, -1)].reverse().forEach((d, i) => { s += +d * (i % 2 === 0 ? 3 : 1); }); return (10 - (s % 10)) % 10 === +c.slice(-1); }
export function gerarChave({ cnpj, emissao, serie, numero, codigo }) {
  codigo = codigo || String(crypto.getRandomValues(new Uint32Array(1))[0] % 100000000).padStart(8, "0");
  const base = `31${aamm(emissao)}${dig(cnpj).padStart(14, "0")}55${String(serie).padStart(3, "0")}${String(numero).padStart(9, "0")}1${codigo}`;
  const chave = base + dv11(base); return { chave, cNF: codigo, cDV: chave.slice(-1), id: "NFe" + chave };
}
export function validarChave(c) { if (!/^\d{44}$/.test(c || "")) throw new ErroEmissao("Chave precisa ter 44 dígitos"); if (+c[43] !== dv11(c.slice(0, 43))) throw new ErroEmissao("Dígito verificador incorreto"); return c; }

function ender(nome, r, rotulo) {
  const cmun = dig(r.codigo_municipio); if (cmun.length !== 7) throw new ErroEmissao(`${rotulo}: código IBGE do município deve ter 7 dígitos.`);
  const uf = String(r.uf || "").toUpperCase().trim(); if (!COD_UF[uf]) throw new ErroEmissao(`${rotulo}: UF inválida.`);
  if (cmun.slice(0, 2) !== COD_UF[uf]) throw new ErroEmissao(`${rotulo}: código do município não pertence à UF ${uf}.`);
  const cep = dig(r.cep); if (cep && cep.length !== 8) throw new ErroEmissao(`${rotulo}: CEP deve ter 8 dígitos.`);
  const fone = dig(r.telefone);
  return E(nome, null, el("xLgr", txt(r.logradouro, 60, 2, `${rotulo}: logradouro`)), el("nro", txt(r.numero || "SN", 60, 1, `${rotulo}: número`)),
    String(r.complemento || "").trim() ? el("xCpl", txt(r.complemento, 60)) : null, el("xBairro", txt(r.bairro, 60, 2, `${rotulo}: bairro`)),
    el("cMun", cmun), el("xMun", txt(r.municipio, 60, 2, `${rotulo}: município`)), el("UF", uf), cep ? el("CEP", cep) : null,
    el("cPais", "1058"), el("xPais", "Brasil"), fone.length >= 6 && fone.length <= 14 ? el("fone", fone) : null);
}

// ---------------------------------------------------------------- montagem
// d = {emitente, destinatario, itens:[{codigo,descricao,ncm,cest,ean,unidade,origem,quantidade,preco,frete,seguro,desconto,outros,obs,cfop,csosn,pis_cst,cofins_cst}],
//      natureza, serie, numero, ambiente, ind_final, ind_pres, pagamentos:[[tPag,valor|null]], info, fin_nfe, referencias, transporte, dh_emissao, cnf, versao}
export function montarNFe(d) {
  const emit = d.emitente;
  const crt = String(emit.crt || "4");
  if (!["1", "4"].includes(crt)) throw new ErroEmissao("Regime da empresa inválido: use MEI ou Simples Nacional (ME/EPP).");
  const pCred = crt === "1" ? dec(emit.p_cred_sn || 0) : 0n; let vCredTot = 0n;
  if (String(emit.uf).toUpperCase() !== "MG") throw new ErroEmissao("Somente emitentes de MG.");
  const cnpj = dig(emit.cnpj); if (cnpj.length !== 14) throw new ErroEmissao("CNPJ do emitente inválido.");
  const ie = dig(emit.ie); if (!ie) throw new ErroEmissao("Inscrição estadual do emitente não informada.");
  if (!["1", "2"].includes(d.ambiente)) throw new ErroEmissao("Ambiente inválido.");
  if (!d.itens?.length) throw new ErroEmissao("A nota não possui itens.");
  if (d.itens.length > 990) throw new ErroEmissao("Limite de 990 itens por NF-e.");
  const emissao = d.dh_emissao ? new Date(d.dh_emissao) : agoraMG();
  if (emissao > new Date(Date.now() + 5 * 60000)) throw new ErroEmissao("A data de emissão não pode ser futura.");
  if (emissao < new Date(Date.now() - 30 * 864e5)) throw new ErroEmissao("A data de emissão não pode ser anterior a 30 dias (rejeição 228).");
  const fin = String(d.fin_nfe || "1"); if (!["1", "2", "3", "4"].includes(fin)) throw new ErroEmissao("Finalidade da emissão inválida.");
  const refs = (d.referencias || []).map(dig).filter(Boolean); refs.forEach(validarChave);
  if (fin !== "1" && !refs.length) throw new ErroEmissao("NF-e complementar, de ajuste ou de devolução exige a chave do documento referenciado.");
  const prim = new Set(d.itens.map(i => dig(i.cfop).slice(0, 1)));
  const tpNF = [...prim].every(p => "123".includes(p)) ? "0" : [...prim].every(p => "567".includes(p)) ? "1" : null;
  if (!tpNF) throw new ErroEmissao("Itens misturam CFOP de entrada e de saída.");
  const ch = gerarChave({ cnpj, emissao, serie: d.serie, numero: d.numero, codigo: d.cnf });
  const dest = d.destinatario, ufDest = String(dest.uf || "").toUpperCase().trim(), idDest = ufDest === "MG" ? "1" : "2";
  const indIE = String(dest.indicador_ie || "9"); if (!["1", "2", "9"].includes(indIE)) throw new ErroEmissao("Destinatário sem indicador de IE (1, 2 ou 9).");
  const indFinal = indIE === "9" ? "1" : String(d.ind_final ?? "1"), indPres = String(d.ind_pres || "1");
  if (!"0123459".includes(indPres) || indPres.length !== 1) throw new ErroEmissao("Indicador de presença inválido.");

  const ide = E("ide", null, el("cUF", "31"), el("cNF", ch.cNF), el("natOp", txt(d.natureza, 60, 1, "Natureza da operação")), el("mod", "55"),
    el("serie", String(+d.serie)), el("nNF", String(+d.numero)), el("dhEmi", dh(emissao)), d.dh_saida ? el("dhSaiEnt", dh(new Date(d.dh_saida))) : null,
    el("tpNF", tpNF), el("idDest", idDest), el("cMunFG", dig(emit.codigo_municipio)), el("tpImp", "1"), el("tpEmis", "1"), el("cDV", ch.cDV),
    el("tpAmb", d.ambiente), el("finNFe", fin), el("indFinal", indFinal), el("indPres", indPres),
    "2349".includes(indPres) ? el("indIntermed", "0") : null, el("procEmi", "0"), el("verProc", "NFE Pro Web " + (d.versao || "1.0")),
    refs.map(r => E("NFref", null, el("refNFe", r))));
  const emitEl = E("emit", null, el("CNPJ", cnpj), el("xNome", txt(emit.razao_social, 60, 2, "Razão social do emitente")),
    String(emit.fantasia || "").trim() ? el("xFant", txt(emit.fantasia, 60)) : null, ender("enderEmit", emit, "Emitente"), el("IE", ie), el("CRT", crt));
  const doc = dig(dest.documento);
  if (![11, 14].includes(doc.length)) throw new ErroEmissao("CPF/CNPJ do destinatário inválido.");
  const nomeDest = d.ambiente === "2" ? XNOME_HOMOLOG : txt(dest.nome, 60, 2, "Nome do destinatário");
  let ieDest = null; if (indIE === "1") { ieDest = dig(dest.ie); if (!ieDest) throw new ErroEmissao("Destinatário contribuinte (indicador 1) sem inscrição estadual."); }
  const email = String(dest.email || "").trim();
  const destEl = E("dest", null, el(doc.length === 14 ? "CNPJ" : "CPF", doc), el("xNome", nomeDest), ender("enderDest", dest, "Destinatário"),
    el("indIEDest", indIE), ieDest ? el("IE", ieDest) : null, /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) ? el("email", email.slice(0, 60)) : null);

  const tot = { vProd: 0n, vFrete: 0n, vSeg: 0n, vDesc: 0n, vOutro: 0n, vPIS: 0n, vCOFINS: 0n };
  const dets = d.itens.map((it, k) => {
    const n = k + 1; let cfop = dig(it.cfop);
    if (!/^[1256]\d{3}$/.test(cfop)) throw new ErroEmissao(`Item ${n}: CFOP inválido.`);
    cfop = (tpNF === "0" ? { 1: "1", 2: "2" } : { 1: "5", 2: "6" })[idDest] + cfop.slice(1);
    const ncm = dig(it.ncm); if (ncm.length !== 8) throw new ErroEmissao(`Item ${n}: NCM deve ter 8 dígitos.`);
    const q = arred(dec(it.quantidade), 4), vun = dec(it.preco);
    if (q <= 0n || vun <= 0n) throw new ErroEmissao(`Item ${n}: quantidade e valor unitário devem ser positivos.`);
    const vProd = arred(mul(q, vun), 2);
    const gtin = dig(it.ean); if (gtin && !gtinValido(gtin)) throw new ErroEmissao(`Item ${n}: código de barras (GTIN) inválido. Deixe vazio para 'SEM GTIN'.`);
    const cest = dig(it.cest); if (cest && cest.length !== 7) throw new ErroEmissao(`Item ${n}: CEST deve ter 7 dígitos.`);
    const un = txt(it.unidade || "UN", 6, 1, `Item ${n}: unidade`);
    const adic = {}; const extras = [["vFrete", "frete"], ["vSeg", "seguro"], ["vDesc", "desconto"], ["vOutro", "outros"]].map(([c, k2]) => {
      const v = arred(dec(it[k2] || 0), 2); if (v < 0n) throw new ErroEmissao(`Item ${n}: ${c} não pode ser negativo.`); adic[c] = v; tot[c] += v; return v > 0n ? el(c, fmt(v)) : null; });
    if (adic.vDesc > vProd) throw new ErroEmissao(`Item ${n}: desconto maior que o valor do produto.`);
    const prod = E("prod", null, el("cProd", txt(it.codigo, 60, 1, `Item ${n}: código`)), el("cEAN", gtin || "SEM GTIN"), el("xProd", txt(it.descricao, 120, 1, `Item ${n}: descrição`)),
      el("NCM", ncm), cest ? el("CEST", cest) : null, el("CFOP", cfop), el("uCom", un), el("qCom", fmt(q, 4)), el("vUnCom", fmtUnit(vun)), el("vProd", fmt(vProd)),
      el("cEANTrib", gtin || "SEM GTIN"), el("uTrib", un), el("qTrib", fmt(q, 4)), el("vUnTrib", fmtUnit(vun)), extras, el("indTot", "1"));
    const orig = String(it.origem ?? "0"); if (!/^[0-8]$/.test(orig)) throw new ErroEmissao(`Item ${n}: origem da mercadoria inválida.`);
    const csosn = String(it.csosn || "102");
    const grupo = ["102", "103", "300", "400"].includes(csosn) ? "ICMSSN102" : csosn === "500" ? "ICMSSN500" : csosn === "900" ? "ICMSSN900" : csosn === "101" && crt === "1" ? "ICMSSN101" : null;
    if (!grupo) throw new ErroEmissao(`Item ${n}: CSOSN ${csosn} não permitido para ${crt === "4" ? "MEI (use 102, 103, 300, 400, 500 ou 900)" : "esta versão (use 101, 102, 103, 300, 400, 500 ou 900)"}.`);
    let cred = [];
    if (grupo === "ICMSSN101") {
      if (pCred <= 0n || pCred > dec(10)) throw new ErroEmissao(`Item ${n}: CSOSN 101 exige a alíquota de crédito de ICMS do Simples (Empresa → Impostos do Simples Nacional).`);
      const base = vProd - adic.vDesc + adic.vFrete + adic.vSeg + adic.vOutro, v = arred(mul(base, pCred) / 100n, 2); vCredTot += v;
      cred = [el("pCredSN", fmt(arred(pCred, 4), 4)), el("vCredICMSSN", fmt(v))];
    }
    const contrib = g => { const cst = String(it[g.toLowerCase() + "_cst"] || "99"); if (!/^\d{2}$/.test(cst)) throw new ErroEmissao(`Item ${n}: CST ${g} inválido.`);
      if (["04", "05", "06", "07", "08", "09"].includes(cst)) return E(g, null, E(g + "NT", null, el("CST", cst)));
      if (["01", "02", "03"].includes(cst)) throw new ErroEmissao(`Item ${n}: CST ${g} ${cst} exige alíquota (no Simples use 49, 99, 07 ou 04).`);
      return E(g, null, E(g + "Outr", null, el("CST", cst), el("vBC", "0.00"), el("p" + g, "0.0000"), el("v" + g, "0.00"))); };
    const imposto = E("imposto", null, E("ICMS", null, E(grupo, null, el("orig", orig), el("CSOSN", csosn), cred)), contrib("PIS"), contrib("COFINS"));
    tot.vProd += vProd;
    const obs = String(it.obs || "").trim();
    return E("det", { nItem: String(n) }, prod, imposto, obs ? el("infAdProd", txt(obs, 500)) : null);
  });
  const vNF = tot.vProd - tot.vDesc + tot.vFrete + tot.vSeg + tot.vOutro;
  const total = E("total", null, E("ICMSTot", null, ["vBC", "vICMS", "vICMSDeson", "vFCP", "vBCST", "vST", "vFCPST", "vFCPSTRet"].map(x => el(x, "0.00")),
    el("vProd", fmt(tot.vProd)), el("vFrete", fmt(tot.vFrete)), el("vSeg", fmt(tot.vSeg)), el("vDesc", fmt(tot.vDesc)), el("vII", "0.00"), el("vIPI", "0.00"),
    el("vIPIDevol", "0.00"), el("vPIS", fmt(tot.vPIS)), el("vCOFINS", fmt(tot.vCOFINS)), el("vOutro", fmt(tot.vOutro)), el("vNF", fmt(vNF))));
  const tr = d.transporte || {}, mod = String(tr.modalidade || (tot.vFrete > 0n ? "0" : "9"));
  if (!MODALIDADES_FRETE[mod]) throw new ErroEmissao("Modalidade do frete inválida.");
  if (mod === "9" && tot.vFrete > 0n) throw new ErroEmissao("Há frete nos itens: escolha a modalidade do frete.");
  const docT = dig(tr.documento), nomeT = String(tr.nome || "").trim(), ufT = String(tr.uf || "").toUpperCase().trim();
  if (docT && ![11, 14].includes(docT.length)) throw new ErroEmissao("Transportador: CPF/CNPJ inválido.");
  if (ufT && !COD_UF[ufT]) throw new ErroEmissao("Transportador: UF inválida.");
  const transp = E("transp", null, el("modFrete", mod), mod !== "9" && (docT || nomeT) ? E("transporta", null, docT ? el(docT.length === 14 ? "CNPJ" : "CPF", docT) : null,
    nomeT ? el("xNome", txt(nomeT, 60, 2, "Transportador: nome")) : null, dig(tr.ie) ? el("IE", dig(tr.ie)) : null, ufT ? el("UF", ufT) : null) : null);
  let formas = d.pagamentos?.length ? d.pagamentos : [["01", null]];
  if (fin === "3" || fin === "4" || tpNF === "0") formas = [["90", 0]];
  let soma = 0n;
  const dets_pag = formas.map(([tp, v], i) => {
    tp = String(tp).padStart(2, "0"); if (!FORMAS_PAGAMENTO[tp]) throw new ErroEmissao(`Forma de pagamento ${tp} inválida.`);
    let val = v === null || v === undefined || v === "" ? (i === formas.length - 1 ? vNF - soma : 0n) : dec(v); if (tp === "90") val = 0n; soma += val;
    return E("detPag", null, el("tPag", tp), tp === "99" ? el("xPag", "Outros") : null, el("vPag", fmt(val)), ["03", "04", "17"].includes(tp) ? E("card", null, el("tpIntegra", "2")) : null);
  });
  if (!formas.some(f => String(f[0]).padStart(2, "0") === "90") && soma < vNF) throw new ErroEmissao("Soma dos pagamentos menor que o total da nota.");
  const pag = E("pag", null, dets_pag, soma > vNF ? el("vTroco", fmt(soma - vNF)) : null);
  const textos = [crt === "4" ? "DOCUMENTO EMITIDO POR MEI OPTANTE PELO SIMPLES NACIONAL. NAO GERA DIREITO A CREDITO FISCAL DE IPI."
    : "DOCUMENTO EMITIDO POR ME OU EPP OPTANTE PELO SIMPLES NACIONAL. NAO GERA DIREITO A CREDITO FISCAL DE IPI."];
  if (vCredTot > 0n) textos.push(`PERMITE O APROVEITAMENTO DO CREDITO DE ICMS NO VALOR DE R$ ${fmt(vCredTot).replace(".", ",")}; CORRESPONDENTE A ALIQUOTA DE ${fmt(arred(pCred, 2)).replace(".", ",")}%, NOS TERMOS DO ART. 23 DA LC 123/2006.`);
  if (String(d.info || "").trim()) textos.push(txt(d.info, 3000));
  const adic = E("infAdic", null, el("infCpl", txt(textos.join(" "), 5000)));
  const rt = d.resp_tec || {};
  const resp = dig(rt.cnpj) ? E("infRespTec", null, el("CNPJ", dig(rt.cnpj)), el("xContato", txt(rt.contato, 60, 2, "Responsável técnico")), el("email", txt(rt.email, 60, 6, "Responsável técnico: e-mail")), el("fone", dig(rt.fone).slice(0, 14) || "0000000000")) : null;
  const inf = E("infNFe", { Id: ch.id, versao: "4.00" }, ide, emitEl, destEl, dets, total, transp, pag, adic, resp);
  return { inf, info: { chave: ch.chave, cNF: ch.cNF, dhEmi: dh(emissao), vNF: fmt(vNF), serie: +d.serie, numero: +d.numero, ambiente: d.ambiente, destinatario: dest.nome || "" } };
}

// ---------------------------------------------------------------- assinatura (XMLDSig enveloped, RSA-SHA1, C14N 1.0)
const b64 = buf => { let s = ""; const u = new Uint8Array(buf); for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode(...u.subarray(i, i + 0x8000)); return btoa(s); };
export function pemParaDer(pem) { const b = atob(pem.replace(/-----[^-]+-----/g, "").replace(/\s+/g, "")); return Uint8Array.from(b, c => c.charCodeAt(0)); }
export async function importarChave(pkcs8Pem) { return crypto.subtle.importKey("pkcs8", pemParaDer(pkcs8Pem), { name: "RSASSA-PKCS1-v1_5", hash: "SHA-1" }, false, ["sign"]); }
const enc = new TextEncoder();
export async function assinar(raizNome, raizAttrs, alvo, chave, certPem) {
  // raiz: elemento que recebe <Signature> como último filho (NFe ou evento); alvo: elemento com Id (infNFe/infEvento)
  const id = alvo.attrs.Id;
  const digest = b64(await crypto.subtle.digest("SHA-1", enc.encode(xml(alvo, NFE))));
  const A = a => ({ Algorithm: a });
  const si = E("SignedInfo", null, E("CanonicalizationMethod", A("http://www.w3.org/TR/2001/REC-xml-c14n-20010315")), E("SignatureMethod", A("http://www.w3.org/2000/09/xmldsig#rsa-sha1")),
    E("Reference", { URI: "#" + id }, E("Transforms", null, E("Transform", A("http://www.w3.org/2000/09/xmldsig#enveloped-signature")), E("Transform", A("http://www.w3.org/TR/2001/REC-xml-c14n-20010315"))),
      E("DigestMethod", A("http://www.w3.org/2000/09/xmldsig#sha1")), el("DigestValue", digest)));
  const valor = b64(await crypto.subtle.sign("RSASSA-PKCS1-v1_5", chave, enc.encode(xml(si, DS))));
  const certB64 = b64(pemParaDer(certPem.match(/-----BEGIN CERTIFICATE-----[\s\S]+?-----END CERTIFICATE-----/)[0]));
  const sig = E("Signature", { xmlns: DS }, si, el("SignatureValue", valor), E("KeyInfo", null, E("X509Data", null, el("X509Certificate", certB64))));
  return xml(E(raizNome, raizAttrs, alvo, sig), NFE);
}
export async function assinarNFe(montada, chave, certPem) { return assinar("NFe", {}, montada.inf, chave, certPem); }

// ---------------------------------------------------------------- SOAP e leitura de respostas
export function envelope(servico, corpo) {
  return `<?xml version="1.0" encoding="utf-8"?><soap12:Envelope xmlns:soap12="http://www.w3.org/2003/05/soap-envelope"><soap12:Body><nfeDadosMsg xmlns="${WSDL}${SERVICOS[servico][0]}">${corpo}</nfeDadosMsg></soap12:Body></soap12:Envelope>`;
}
export async function chamarSefaz(fetcher, servico, ambiente, corpo) {
  const [nome, acao] = SERVICOS[servico];
  const r = await fetcher.fetch(BASE_URL[ambiente] + nome, { method: "POST", redirect: "manual", body: envelope(servico, corpo),
    headers: { "Content-Type": `application/soap+xml; charset=utf-8; action="${WSDL}${nome}/${acao}"` } });
  if (r.status !== 200) throw new Error(`SEFAZ respondeu HTTP ${r.status} em ${nome}.`);
  const t = await r.text(); if (t.length > 5_000_000) throw new Error("Resposta da SEFAZ acima do limite.");
  if (/<(\w+:)?Fault[\s>]/.test(t)) throw new Error("SOAP Fault: " + t.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().slice(0, 300));
  return t;
}
export const tag = (x, n) => { const m = String(x || "").match(new RegExp(`<(?:\\w+:)?${n}(?:\\s[^>]*)?>([\\s\\S]*?)</(?:\\w+:)?${n}>`)); return m ? m[1].trim() : null; };
export const bloco = (x, n) => { const m = String(x || "").match(new RegExp(`<(?:\\w+:)?${n}(?:\\s[^>]*)?>[\\s\\S]*?</(?:\\w+:)?${n}>`)); return m ? m[0] : null; };
export const lote = (nfe, sinc) => `<enviNFe xmlns="${NFE}" versao="4.00"><idLote>${Date.now().toString().slice(-15)}</idLote><indSinc>${sinc ? 1 : 0}</indSinc>${nfe}</enviNFe>`;
export const consReci = (amb, rec) => `<consReciNFe xmlns="${NFE}" versao="4.00"><tpAmb>${amb}</tpAmb><nRec>${dig(rec)}</nRec></consReciNFe>`;
export const consSit = (amb, chave) => `<consSitNFe xmlns="${NFE}" versao="4.00"><tpAmb>${amb}</tpAmb><xServ>CONSULTAR</xServ><chNFe>${validarChave(chave)}</chNFe></consSitNFe>`;
export const consStatus = amb => `<consStatServ xmlns="${NFE}" versao="4.00"><tpAmb>${amb}</tpAmb><cUF>31</cUF><xServ>STATUS</xServ></consStatServ>`;
export function lerProt(prot) { return { chave: tag(prot, "chNFe"), cStat: tag(prot, "cStat"), xMotivo: tag(prot, "xMotivo"), nProt: tag(prot, "nProt"), dhRecbto: tag(prot, "dhRecbto") }; }
export function situacaoProt(c) { return ["100", "150"].includes(c) ? "AUTORIZADA" : ["110", "301", "302", "303"].includes(c) ? "DENEGADA" : "REJEITADA"; }
export const montarProc = (nfe, prot) => `<?xml version="1.0" encoding="UTF-8"?><nfeProc xmlns="${NFE}" versao="4.00">${nfe}${prot.includes("xmlns=") ? prot : prot.replace(/^<protNFe/, `<protNFe xmlns="${NFE}"`)}</nfeProc>`;

// ---------------------------------------------------------------- eventos
export async function evento({ chave, ambiente, tpEvento, seq, desc, extra, chaveRSA, certPem }) {
  validarChave(chave);
  const inf = E("infEvento", { Id: `ID${tpEvento}${chave}${String(seq).padStart(2, "0")}` }, el("cOrgao", "31"), el("tpAmb", ambiente), el("CNPJ", chave.slice(6, 20)),
    el("chNFe", chave), el("dhEvento", dh(agoraMG())), el("tpEvento", tpEvento), el("nSeqEvento", String(seq)), el("verEvento", "1.00"),
    E("detEvento", { versao: "1.00" }, el("descEvento", desc), extra.map(([n, v]) => el(n, v))));
  const ev = await assinar("evento", { versao: "1.00" }, inf, chaveRSA, certPem);
  return { ev, corpo: `<envEvento xmlns="${NFE}" versao="1.00"><idLote>${Date.now().toString().slice(-15)}</idLote>${ev}</envEvento>` };
}
export const cancelamento = (o) => evento({ ...o, tpEvento: "110111", seq: 1, desc: "Cancelamento", extra: [["nProt", o.protocolo], ["xJust", txt(o.justificativa, 255, 15, "Justificativa")]] });
export const cartaCorrecao = (o) => evento({ ...o, tpEvento: "110110", desc: "Carta de Correcao", extra: [["xCorrecao", txt(o.correcao, 1000, 15, "Correção")], ["xCondUso", TEXTO_CCE]] });
export function lerRetEvento(resp, ev) {
  const ret = bloco(resp, "retEnvEvento"); if (!ret) throw new Error("Resposta sem retEnvEvento.");
  if (tag(ret, "cStat") !== "128") return { ok: false, cStat: tag(ret, "cStat"), xMotivo: tag(ret, "xMotivo") };
  const re = bloco(ret, "retEvento"), inf = bloco(re, "infEvento");
  const r = { cStat: tag(inf, "cStat"), xMotivo: tag(inf, "xMotivo"), nProt: tag(inf, "nProt") };
  r.ok = ["135", "136", "155"].includes(r.cStat);
  if (r.ok) r.proc = `<?xml version="1.0" encoding="UTF-8"?><procEventoNFe xmlns="${NFE}" versao="1.00">${ev}${re.includes("xmlns=") ? re : re.replace(/^<retEvento/, `<retEvento xmlns="${NFE}"`)}</procEventoNFe>`;
  return r;
}
