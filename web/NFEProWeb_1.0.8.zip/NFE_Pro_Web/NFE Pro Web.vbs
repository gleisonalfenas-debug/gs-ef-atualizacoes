Set sh = CreateObject("WScript.Shell")
Set fs = CreateObject("Scripting.FileSystemObject")
pasta = fs.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = pasta
If sh.Run("cmd /c where node", 0, True) <> 0 Then
  MsgBox "Instale o Node.js LTS (https://nodejs.org) e abra de novo.", 48, "NFE Pro Web"
  WScript.Quit
End If
' Abre o NFE Pro Web sem a janela preta (o registro fica em nfepro_log.txt). Fecha sozinho quando o navegador fecha.
sh.Run "cmd /c node --experimental-sqlite --no-warnings ferramentas\iniciar.mjs > nfepro_log.txt 2>&1", 0, False
