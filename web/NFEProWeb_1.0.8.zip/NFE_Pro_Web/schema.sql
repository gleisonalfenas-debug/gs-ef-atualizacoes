-- NFE Pro Web — banco D1 (SQLite) da Cloudflare
CREATE TABLE IF NOT EXISTS contas (
  id INTEGER PRIMARY KEY, email TEXT NOT NULL UNIQUE, nome TEXT, senha TEXT NOT NULL, sal TEXT NOT NULL,
  papel TEXT NOT NULL DEFAULT 'cliente', status TEXT NOT NULL DEFAULT 'ativo', valido_ate TEXT, criado_em TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessoes (token TEXT PRIMARY KEY, conta_id INTEGER NOT NULL, expira TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS empresas (
  id INTEGER PRIMARY KEY, conta_id INTEGER NOT NULL UNIQUE, cnpj TEXT, ie TEXT, razao_social TEXT, fantasia TEXT,
  logradouro TEXT, numero TEXT, complemento TEXT, bairro TEXT, codigo_municipio TEXT, municipio TEXT, uf TEXT DEFAULT 'MG',
  cep TEXT, telefone TEXT, ambiente TEXT NOT NULL DEFAULT '2', serie INTEGER NOT NULL DEFAULT 1,
  proximo_numero INTEGER NOT NULL DEFAULT 1, proximo_homolog INTEGER NOT NULL DEFAULT 1,
  cert_pem TEXT, chave_cifrada TEXT, cert_nome TEXT, cert_validade TEXT, mtls_id TEXT, atualizado_em TEXT);
CREATE TABLE IF NOT EXISTS clientes (
  id INTEGER PRIMARY KEY, empresa_id INTEGER NOT NULL, nome TEXT NOT NULL, documento TEXT, ie TEXT,
  indicador_ie TEXT DEFAULT '9', email TEXT, telefone TEXT, cep TEXT, logradouro TEXT, numero TEXT, complemento TEXT,
  bairro TEXT, codigo_municipio TEXT, municipio TEXT, uf TEXT);
CREATE TABLE IF NOT EXISTS produtos (
  id INTEGER PRIMARY KEY, empresa_id INTEGER NOT NULL, codigo TEXT NOT NULL, descricao TEXT NOT NULL, ncm TEXT, cest TEXT,
  ean TEXT, unidade TEXT DEFAULT 'UN', preco TEXT DEFAULT '0', origem TEXT DEFAULT '0', csosn TEXT DEFAULT '102',
  pis_cst TEXT DEFAULT '99');
CREATE TABLE IF NOT EXISTS rascunhos (id INTEGER PRIMARY KEY, empresa_id INTEGER NOT NULL, dados TEXT NOT NULL, atualizado_em TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS notas (
  id INTEGER PRIMARY KEY, empresa_id INTEGER NOT NULL, rascunho_id INTEGER, ambiente TEXT NOT NULL, serie INTEGER NOT NULL,
  numero INTEGER NOT NULL, chave TEXT NOT NULL UNIQUE, situacao TEXT NOT NULL, cstat TEXT, motivo TEXT, protocolo TEXT,
  recibo TEXT, dh_emissao TEXT, total TEXT, destinatario TEXT, dados TEXT, xml_assinado TEXT, xml_autorizado TEXT,
  criada_em TEXT NOT NULL, atualizada_em TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_notas_emp ON notas(empresa_id, dh_emissao);
CREATE TABLE IF NOT EXISTS eventos (
  id INTEGER PRIMARY KEY, chave TEXT NOT NULL, tipo TEXT NOT NULL, seq INTEGER NOT NULL, cstat TEXT, motivo TEXT,
  protocolo TEXT, texto TEXT, xml TEXT, criado_em TEXT NOT NULL, UNIQUE(chave, tipo, seq));
