// Importa o backup do NFE Pro do Windows (gleison_fiscal.db, ou a pasta NFE-Pro_backup_...) para o NFE Pro Web no PC.
// Traz empresa, clientes, produtos, notas emitidas (com XML) e eventos. O certificado A1 é enviado de novo na tela Empresa.
// Uso: node --experimental-sqlite ferramentas/importar_backup.mjs <backup> [e-mail da conta] [banco web]
import { DatabaseSync } from "node:sqlite"; import fs from "node:fs"; import path from "node:path"; import { fileURLToPath } from "node:url";
import { tag as tagX, bloco } from "../src/nfe.js";
const tag = (x, n) => { const v = tagX(x, n); return v === null ? null : v.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&amp;/g, "&"); };
const raiz = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
let [origem, email = "gleisonalfenas@icloud.com", destino = path.join(raiz, "nfepro_teste.db")] = process.argv.slice(2);
const sair = m => { console.log("\n  " + m + "\n"); process.exit(1); };
if (!origem) sair("Informe o backup: arraste a pasta NFE-Pro_backup_... (ou o arquivo gleison_fiscal.db) em cima do importar_backup.bat.");
origem = origem.replace(/^"|"$/g, "");
if (fs.existsSync(origem) && fs.statSync(origem).isDirectory()) origem = path.join(origem, "gleison_fiscal.db");
if (!fs.existsSync(origem)) sair("Não achei o arquivo " + origem);
if (!fs.existsSync(destino)) sair("Abra antes o testar_no_pc.bat e crie a sua conta (" + email + "); depois rode a importação de novo.");
const A = new DatabaseSync(origem, { readOnly: true }), W = new DatabaseSync(destino);
W.exec(fs.readFileSync(path.join(raiz, "schema.sql"), "utf8"));
const conta = W.prepare("SELECT * FROM contas WHERE email=?").get(email.toLowerCase());
if (!conta) sair("Conta " + email + " não existe no NFE Pro Web. Crie a conta no testar_no_pc.bat e rode de novo.");
const tabelas = new Set(A.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map(r => r.name));
const cols = t => new Set(tabelas.has(t) ? A.prepare(`PRAGMA table_info(${t})`).all().map(r => r.name) : []);
const c = A.prepare("SELECT * FROM companies ORDER BY active DESC, id LIMIT 1").get(); if (!c) sair("O backup não tem empresa cadastrada.");
const txt = v => (v === null || v === undefined ? "" : v instanceof Uint8Array ? Buffer.from(v).toString("utf8") : String(v));
const agora = new Date().toISOString();
let emp = W.prepare("SELECT * FROM empresas WHERE conta_id=?").get(conta.id);
if (!emp) { W.prepare("INSERT INTO empresas (conta_id, atualizado_em) VALUES (?,?)").run(conta.id, agora); emp = W.prepare("SELECT * FROM empresas WHERE conta_id=?").get(conta.id); }
const seq = amb => tabelas.has("nfe_sequencia_emissao") ? (A.prepare("SELECT MAX(proximo) p FROM nfe_sequencia_emissao WHERE company_id=? AND ambiente=?").get(c.id, amb)?.p || 0) : 0;
const maxNum = amb => tabelas.has("nfe_emitidas") ? (A.prepare("SELECT MAX(numero) n FROM nfe_emitidas WHERE company_id=? AND ambiente=?").get(c.id, amb)?.n || 0) : 0;
const prox = amb => Math.max(seq(amb), maxNum(amb) + 1, amb === "1" ? (+c.ultima_nfe_autorizada || 0) + 1 : 1, +(amb === "1" ? emp.proximo_numero : emp.proximo_homolog) || 1);
W.prepare(`UPDATE empresas SET cnpj=?, ie=?, razao_social=?, fantasia=?, logradouro=?, numero=?, complemento=?, bairro=?, codigo_municipio=?, municipio=?, uf=?, cep=?, telefone=?,
  ambiente=?, serie=?, proximo_numero=?, proximo_homolog=?, atualizado_em=? WHERE id=?`).run(String(c.cnpj || "").replace(/\D/g, ""), String(c.ie || "").replace(/\D/g, ""), c.legal_name || "", c.trade_name || "",
  c.logradouro || "", c.numero || "", c.complemento || "", c.bairro || "", c.codigo_municipio || "", c.municipio || "", c.uf || "MG", String(c.cep || "").replace(/\D/g, ""), c.telefone || "",
  c.ambiente_nfe === "1" ? "1" : "2", +c.serie_nfe || 1, prox("1"), prox("2"), agora, emp.id);
// clientes
const ccli = cols("customers"); let nCli = 0;
for (const r of A.prepare("SELECT * FROM customers WHERE company_id=?").all(c.id)) {
  const doc = String(r.document || "").replace(/\D/g, "");
  if (W.prepare("SELECT 1 FROM clientes WHERE empresa_id=? AND nome=? AND COALESCE(documento,'')=?").get(emp.id, r.name, doc)) continue;
  const g = k => (ccli.has(k) ? r[k] ?? "" : "");
  W.prepare("INSERT INTO clientes (empresa_id, nome, documento, ie, indicador_ie, email, telefone, cep, logradouro, numero, complemento, bairro, codigo_municipio, municipio, uf) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
    .run(emp.id, r.name, doc, r.ie || "", g("indicador_ie") || (r.ie ? "1" : "9"), r.email || "", g("telefone"), String(g("cep")).replace(/\D/g, ""), g("logradouro"), g("numero"), g("complemento"), g("bairro"), g("codigo_municipio"), g("municipio"), g("uf") || "MG"); nCli++; }
// produtos
const cprod = cols("products"); let nProd = 0;
for (const r of A.prepare("SELECT * FROM products WHERE company_id=?").all(c.id)) {
  const cod = String(r.code || r.id);
  if (W.prepare("SELECT 1 FROM produtos WHERE empresa_id=? AND codigo=?").get(emp.id, cod)) continue;
  W.prepare("INSERT INTO produtos (empresa_id, codigo, descricao, ncm, cest, ean, unidade, preco, origem, csosn, pis_cst) VALUES (?,?,?,?,?,?,?,?,?,?,?)")
    .run(emp.id, cod, r.description, r.ncm || "", r.cest || "", cprod.has("ean") ? r.ean || "" : "", r.unit || "UN", String(r.price ?? 0), String(r.origin ?? "0") || "0", "102", "99"); nProd++; }
// notas (com os dados lidos do XML, para o DANFE)
function dadosDoXml(x) {
  const dest = bloco(x, "dest") || "", ed = bloco(dest, "enderDest") || "";
  const itens = [...x.matchAll(/<det\s[^>]*>[\s\S]*?<\/det>/g)].map(m => m[0]).map(d => ({ codigo: tag(d, "cProd"), descricao: tag(d, "xProd"), ncm: tag(d, "NCM"), cfop: tag(d, "CFOP"),
    unidade: tag(d, "uCom"), quantidade: tag(d, "qCom"), preco: tag(d, "vUnCom"), desconto: tag(bloco(d, "prod"), "vDesc") || "0", frete: tag(bloco(d, "prod"), "vFrete") || "0", csosn: tag(d, "CSOSN") || "" }));
  return { natureza: tag(x, "natOp"), info: (tag(x, "infCpl") || "").replace(/^DOCUMENTO EMITIDO POR M\w+ OPTANTE PELO SIMPLES NACIONAL\. NAO GERA DIREITO A CREDITO FISCAL DE IPI\.\s*/, ""), itens,
    cliente: { nome: tag(dest, "xNome"), documento: tag(dest, "CNPJ") || tag(dest, "CPF"), ie: tag(dest, "IE") || "", logradouro: tag(ed, "xLgr"), numero: tag(ed, "nro"), complemento: tag(ed, "xCpl") || "",
      bairro: tag(ed, "xBairro"), municipio: tag(ed, "xMun"), uf: tag(ed, "UF"), cep: tag(ed, "CEP") || "", codigo_municipio: tag(ed, "cMun") } };
}
let nNotas = 0, nEv = 0;
if (tabelas.has("nfe_emitidas")) for (const r of A.prepare("SELECT * FROM nfe_emitidas WHERE company_id=?").all(c.id)) {
  if (W.prepare("SELECT 1 FROM notas WHERE chave=?").get(r.chave)) continue;
  const xa = txt(r.xml_assinado), xp = txt(r.xml_autorizado), x = xp || xa;
  W.prepare("INSERT INTO notas (empresa_id, ambiente, serie, numero, chave, situacao, cstat, motivo, protocolo, recibo, dh_emissao, total, destinatario, dados, xml_assinado, xml_autorizado, criada_em, atualizada_em) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
    .run(emp.id, r.ambiente, r.serie, r.numero, r.chave, r.situacao, r.cstat, r.motivo, r.protocolo, r.recibo, r.dh_emissao, r.total, r.destinatario, x ? JSON.stringify(dadosDoXml(x)) : "{}", xa || null, xp || null, r.criada_em || agora, r.atualizada_em || agora); nNotas++; }
if (tabelas.has("nfe_eventos")) for (const r of A.prepare("SELECT e.* FROM nfe_eventos e JOIN nfe_emitidas n ON n.chave=e.chave WHERE n.company_id=?").all(c.id)) {
  const res = W.prepare("INSERT OR IGNORE INTO eventos (chave, tipo, seq, cstat, motivo, protocolo, texto, xml, criado_em) VALUES (?,?,?,?,?,?,?,?,?)").run(r.chave, r.tipo, r.seq, r.cstat, r.motivo, r.protocolo, r.texto, txt(r.xml) || null, r.criado_em || agora); nEv += res.changes; }
const e2 = W.prepare("SELECT * FROM empresas WHERE id=?").get(emp.id);
console.log(`\n  Importado para a conta ${email}:\n  Empresa: ${e2.razao_social} (${e2.cnpj})\n  Clientes novos: ${nCli}   Produtos novos: ${nProd}   Notas: ${nNotas}   Eventos: ${nEv}\n  Próximo número: produção ${e2.proximo_numero}, homologação ${e2.proximo_homolog}\n\n  Falta só enviar o certificado A1 em Empresa e certificado.\n`);
