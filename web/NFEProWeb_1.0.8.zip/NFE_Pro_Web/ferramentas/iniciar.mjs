// Abre o NFE Pro Web no PC: primeiro procura atualização (se houver internet), depois sobe o sistema.
import { atualizar } from "./atualizar.mjs";
try {
  const r = await atualizar();
  console.log(r.atualizado ? `\n  ✔ NFE Pro Web atualizado: ${r.anterior} → ${r.versao}\n` : `\n  Versão ${r.versao} (já é a mais recente)\n`);
} catch (e) { console.log(`\n  Não foi possível procurar atualização agora (${e.message}). Abrindo a versão atual.\n`); }
await import("../test/servidor_local.mjs?" + Date.now());
