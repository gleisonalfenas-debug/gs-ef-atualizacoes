# NFE Pro Web (Cloudflare)

Versão web do NFE Pro: vários clientes MEI, cada um com login, empresa e certificado A1 próprios, e você como administrador.
Fica só nesta pasta `web/` e no ramo `nfepro-web` do GitHub, **sem mudar nada** do NFE Pro do Windows nem do NFS-e PRO.

## O que tem
- Entrar / criar conta (o e-mail de `ADMIN_EMAIL` vira administrador; os outros ganham `DIAS_TESTE` dias de teste).
- Painel com faturamento e limite do MEI (81 mil em 2026, 110 mil em 2027, 140 mil de 2028 em diante).
- Nova NF-e (modelo 55, CRT 4): natureza com CFOP, troca 5→6 sozinha para cliente de outro estado, devolução com chave referenciada, frete, pagamento e informações complementares.
- Rascunhos (o número é reaproveitado se a nota do rascunho for rejeitada).
- Notas emitidas: DANFE (imprimir ou salvar em PDF), XML "Cliente - NF n.xml", consultar situação, carta de correção, cancelamento e **Importar XML de outro sistema** (vendas da própria empresa e cancelamentos; vários arquivos de uma vez).
- Clientes e produtos (CEP preenche endereço e código IBGE pelo ViaCEP), empresa e certificado A1.
- Administração: contas, bloqueio e ativação dos certificados.
- **Licença igual à do NFE Pro Windows**: tela Licença com "Pagar mensalidade" (Mercado Pago, liberação automática), "Já paguei - verificar agora" e "Ativar teste grátis". Usa o mesmo servidor nfspro.com.br: cada conta web aparece em nfspro.com.br → NFE Pro → Computadores com "(web)" no nome, e lá valem o valor, os dias de teste, mudar vencimento, transferir, excluir e os avisos por e-mail/WhatsApp com comprovante.

O XML e a assinatura foram conferidos com o validador oficial (XSD PL_010h) e com a verificação de assinatura do NFE Pro do Windows.
A comunicação com a SEFAZ de verdade só pode ser testada depois de publicado, com um certificado real, **primeiro em homologação**.

## Publicar (uma vez)
Precisa do Node.js (https://nodejs.org, versão LTS) e de uma conta na Cloudflare.
Recomendo o plano **Workers Paid (US$ 5/mês)**: no gratuito o limite de processamento por pedido (10 ms) é pouco para assinar notas.

Abra o Prompt de Comando dentro da pasta `web` e rode:

1. `npx wrangler login`  (abre o navegador para autorizar)
2. `npx wrangler d1 create nfepro-web`  → copie o `database_id` mostrado para o `wrangler.toml`
3. `npx wrangler d1 execute nfepro-web --remote --file=schema.sql`
4. No `wrangler.toml`, preencha `ADMIN_EMAIL`, `SUPORTE` e `CF_ACCOUNT_ID` (painel da Cloudflare → Workers → lado direito "Account ID").
5. `npx wrangler secret put CHAVE_MESTRA`  → digite uma frase longa e aleatória. **Guarde uma cópia**: sem ela as chaves dos certificados não abrem mais.
6. Crie um token em Cloudflare → Meu perfil → API Tokens → Create Token → Custom, permissão **Account → SSL and Certificates → Edit**, e rode `npx wrangler secret put CF_API_TOKEN` colando o token.
7. `npx wrangler deploy`  → aparece o endereço, por exemplo `https://nfepro-web.SEU-NOME.workers.dev`.
8. Abra o endereço e crie a conta com o e-mail do `ADMIN_EMAIL`.

Domínio próprio (opcional): Cloudflare → Workers → nfepro-web → Settings → Domains & Routes → Add → Custom domain.

## Cliente novo (certificado)
A Cloudflare só usa um certificado de cliente depois que ele entra no `wrangler.toml`. Por isso:

1. O cliente cria a conta, preenche Empresa e envia o certificado (.pfx). O arquivo é aberto no navegador dele; a senha não vai para o servidor.
2. O servidor manda o certificado para a Cloudflare e guarda a chave cifrada.
3. Em **Administração** aparece "Certificados aguardando ativação" com um bloco pronto. Copie o bloco, cole no fim do `wrangler.toml` (substituindo o bloco anterior de certificados) e rode `npx wrangler deploy` (ou dê dois cliques em `publicar_web.bat`).
4. Pronto: o cliente já pode emitir. Comece em **Homologação** e troque para **Produção** em Empresa quando estiver tudo certo.

## Testar no seu PC, sem hospedar
1. Instale o Node.js LTS (https://nodejs.org).
2. Dê dois cliques em **`NFE Pro Web.vbs`** (abre sem a janela preta e fecha sozinho quando você fecha o navegador). Dica: botão direito nele → Enviar para → Área de trabalho (criar atalho). O `testar_no_pc.bat` faz o mesmo, mas mostrando a janela preta.
3. Crie a conta com o e-mail do administrador (gleisonalfenas@icloud.com) e teste à vontade.

Nesse modo a **SEFAZ é simulada**: as notas saem "autorizadas" de mentira e não valem nada. Os dados ficam no arquivo `nfepro_teste.db` (apague para começar do zero).

**Atualização automática:** toda vez que abre, o `testar_no_pc.bat` procura atualização na internet. Se houver, baixa, confere a assinatura e troca os arquivos sozinho, sem mexer no banco (antes faz uma cópia dele em `backups`).

**Tudo fica salvo** (empresa, clientes, produtos, rascunhos e notas) no arquivo `nfepro_teste.db`, nesta pasta. Fechar a janela ou desligar o PC não apaga nada.
- **Backup:** pela tela, em **Empresa e certificado → Backup dos seus dados → Baixar backup** (arquivo .json com tudo; para voltar, use **Restaurar**). No PC também dá para usar `fazer_backup.bat` (copia o banco para Documentos com a data).
- **Trazer o backup do programa do Windows:** pela tela, em **Empresa e certificado → Importar backup do programa do Windows**, escolha o arquivo `gleison_fiscal.db` que fica dentro da pasta `NFE-Pro_backup_...` (funciona também na versão hospedada). Ou, no PC, dê dois cliques em `importar_backup.bat` e arraste a pasta `NFE-Pro_backup_...` (ou o arquivo `gleison_fiscal.db`). Ele traz empresa, clientes, produtos, notas com XML/DANFE e eventos, e acerta o próximo número. Pode rodar mais de uma vez: o que já existe não duplica. O certificado A1 você envia de novo em Empresa e certificado.

Teste automático (para o desenvolvedor): `node --experimental-sqlite web/test/teste_local.mjs <pasta com key.pem e cert.pem>` — usa banco e SEFAZ simulados.
