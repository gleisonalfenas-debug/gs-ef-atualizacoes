@echo off
cd /d "%~dp0"
echo Publicando o NFE Pro Web na Cloudflare...
call npx wrangler deploy
pause
