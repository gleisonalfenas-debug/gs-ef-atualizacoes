@echo off
cd /d "%~dp0"
if not exist nfepro_teste.db (echo Ainda nao ha banco de dados para copiar. & pause & exit /b)
for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyy-MM-dd_HHmmss"') do set D=%%i
set "DEST=%USERPROFILE%\Documents\NFE-Pro-Web_backup_%D%.db"
copy /y nfepro_teste.db "%DEST%" >nul && echo Backup salvo em: %DEST%
echo Para voltar um backup: feche o testar_no_pc.bat e copie o arquivo de volta para esta pasta com o nome nfepro_teste.db
pause
