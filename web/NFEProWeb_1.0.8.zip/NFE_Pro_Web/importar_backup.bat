@echo off
cd /d "%~dp0"
title NFE Pro Web - importar backup do programa do Windows
where node >nul 2>nul || (echo Instale o Node.js LTS em https://nodejs.org e rode de novo. & pause & exit /b)
set "ORIGEM=%~1"
if "%ORIGEM%"=="" set /p ORIGEM=Arraste aqui a pasta NFE-Pro_backup_... (ou o gleison_fiscal.db) e aperte Enter: 
set /p EMAIL=E-mail da sua conta no NFE Pro Web [gleisonalfenas@icloud.com]: 
if "%EMAIL%"=="" set "EMAIL=gleisonalfenas@icloud.com"
node --experimental-sqlite --no-warnings ferramentas\importar_backup.mjs "%ORIGEM%" "%EMAIL%"
pause
