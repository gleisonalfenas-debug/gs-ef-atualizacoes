@echo off
cd /d "%~dp0"
title NFE Pro Web
where node >nul 2>nul || (echo Instale o Node.js LTS em https://nodejs.org e rode de novo. & pause & exit /b)
node --experimental-sqlite --no-warnings ferramentas\iniciar.mjs
pause
